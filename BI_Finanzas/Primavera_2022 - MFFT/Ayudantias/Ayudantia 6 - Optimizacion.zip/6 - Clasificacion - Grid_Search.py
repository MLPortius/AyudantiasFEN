# -*- coding: utf-8 -*-
"""
Created on Sun Nov  6 04:48:23 2022

@author: Andriu
"""


#%% INSTALAR LIBRERIAS

# pip install imblearn

#%% IMPORTAR LIBRERIAS

import warnings
warnings.filterwarnings('ignore')

# DATOS
import numpy as np
import pandas as pd

# PREPROCESOS
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.feature_selection import mutual_info_classif
from imblearn.over_sampling import SMOTE

# MODELOS DE CLASIFICACION
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier

# METRICAS CLASIFICACION
from sklearn.metrics import classification_report
from sklearn.metrics import roc_auc_score

#%% CARGAR DATOS

data = pd.read_excel('BD_Ratios_TipoCambio_Preparado.xlsx')
data.set_index('ID',inplace=True,drop=True)

#%% PREPROCESOS CLASIFICACION

Y = data.iloc[:,0]
X = data.iloc[:,1:]

# TRAIN TEST SPLIT
xtr, xts, ytr, yts = train_test_split(X,Y,test_size=0.2,random_state=14)

# ZSCORE
zscaler = StandardScaler()
xstr = zscaler.fit_transform(xtr)
xsts = zscaler.transform(xts)

xstr = pd.DataFrame(xstr,index=xtr.index,columns=xtr.columns)
xsts = pd.DataFrame(xsts,index=xts.index,columns=xts.columns)

# FEATURE SELECTION (ENTRENO CON TRAINING)
info = mutual_info_classif(xstr, ytr, random_state=14)
info = pd.Series(info,index=xstr.columns)
info.sort_values(ascending=False,inplace=True)

p = int(np.round(len(info) * 0.1, 0))
selected = list(info.iloc[:p].index)

xftr = xstr.loc[:,selected]
xfts = xsts.loc[:,selected]


# BALANCEO DE CLASES (SOLO EN TRAINING)
print(ytr.value_counts()/len(ytr)) # BALANCE ORIGINAL

sm = SMOTE(random_state=14)

xbtr, ybtr = sm.fit_resample(xftr,ytr)

print(ybtr.value_counts()/len(ybtr)) # BALANCE NUEVO


#%% GRID_SEARCH REGRESION LOGISTICA

import pickle

l1_ratio_grid = [0,0.25,0.5,0.75,1]
C_grid = [0.1,0.5,1,1.5,2,2.5,5]
iter_grid = [25,50,100,150,200,300,500,1000]

lr_grid = []
for j in l1_ratio_grid:
    for k in C_grid:
        for i in iter_grid:
            lr_grid.append([j,k,i])
del(j,k,i)

LOGREG = []
for g in lr_grid:
    print(g,'...')
    model = LogisticRegression(penalty='elasticnet',solver='saga',l1_ratio=g[0],C=g[1],max_iter=g[2],random_state=14,warm_start=True)
    model.fit(xbtr,ybtr)
    yp = model.predict(xfts)
    auc = roc_auc_score(yts, yp)
    LOGREG.append([g,auc])
    

LOGREG_DF = pd.DataFrame(LOGREG,columns=['CONF','AUC'])
LOGREG_DF.sort_values('AUC',ascending=False,inplace=True)
LR_OPT = LOGREG_DF['CONF'].iloc[0]

# with open('OUTPUT/LOGREG.pickle','wb') as f:
#     pickle.dump(LOGREG_DF,f,pickle.HIGHEST_PROTOCOL)

#%% GRID_SEARCH DTREE

crit_grid = ['gini','entropy','log_loss']
splitter_g = ['best','random']
min_samples_split_g = [2,3,4,5,6,7,8,9,10,15,20,25,30,40,50]
min_samples_leaf_g = [1,2,3,4,5,6,7,8,9,10,15,20,25,30,40,50]

dt_grid = []
for j in crit_grid:
    for k in splitter_g:
            for i in min_samples_split_g:
                for l in min_samples_leaf_g:
                    dt_grid.append([j,k,i,l])
            
del(j,k,i,l)

DTREE = []
for g in dt_grid:
    print(g,'...')
    model = DecisionTreeClassifier(criterion=g[0],splitter=g[1],min_samples_split=g[2],
                                   min_samples_leaf=g[3],random_state=14)
    model.fit(xbtr,ybtr)
    yp = model.predict(xfts)
    auc = roc_auc_score(yts, yp)
    DTREE.append([g,auc])
    
DTREE_DF = pd.DataFrame(DTREE,columns=['CONF','AUC'])
DTREE_DF.sort_values('AUC',ascending=False,inplace=True)
DT_OPT = DTREE_DF['CONF'].iloc[0]

with open('OUTPUT/DTREE.pickle','wb') as f:
      pickle.dump(DTREE_DF,f,pickle.HIGHEST_PROTOCOL)
    
#%% GRID_SEARCH RFOREST

crit_grid = ['gini','entropy','log_loss']
estimat_grid = [2,3,4,5,6,7,8,9,10,15,25,50,75,100,150,300,500]
min_samples_split_g = [2,3,4,5,10,15,20,25,50]
min_samples_leaf_g = [1,2,3,4,5,10,15,20,25,50]

rf_grid = []
for j in crit_grid:
    for k in estimat_grid:
            for i in min_samples_split_g:
                for l in min_samples_leaf_g:
                    rf_grid.append([j,k,i,l])            
del(j,k,i,l)


RFOREST = []
for g in rf_grid:
    print(g,'...')
    model = RandomForestClassifier(criterion=g[0],n_estimators=g[1],min_samples_split=g[2],
                                   min_samples_leaf=g[3],random_state=14,warm_start=True)
    model.fit(xbtr,ybtr)
    yp = model.predict(xfts)
    auc = roc_auc_score(yts, yp)
    RFOREST.append([g,auc])
    
RFOREST_DF = pd.DataFrame(RFOREST,columns=['CONF','AUC'])
RFOREST_DF.sort_values('AUC',ascending=False,inplace=True)
RF_OPT = RFOREST_DF['CONF'].iloc[0]

# with open('OUTPUT/RFOREST.pickle','wb') as f:
#       pickle.dump(RFOREST_DF,f,pickle.HIGHEST_PROTOCOL)
    
#%% GRID_SEARCH MLPC

hid_grid = [5,10,15,20,25,50,75,100,150,200,500]
activation_grid = ['relu','identity','logistic','tanh']
solver_grid = ['lbfgs','sgd','adam']
lr_grid = ['constant','invscaling','adaptive']
iter_grid = [25,50,100,150,200,300,500,1000]
momentum_grid = [0,0.3,0.6,0.9,1]

mlp_grid = []
for i in hid_grid:
    for j in activation_grid:
        for k in solver_grid:
            for l in lr_grid:
                for n in iter_grid:
                    for m in momentum_grid:
                        mlp_grid.append([i,j,k,l,n,m])
                    
MLPC = []
for g in mlp_grid:
    print(g,'...')
    model = MLPClassifier(hidden_layer_sizes=(g[0],),activation=g[1],solver=g[2],
                          learning_rate=g[3],max_iter=g[4],momentum=g[5],
                          random_state=14,early_stopping=True,warm_start=True)
    model.fit(xbtr,ybtr)
    yp = model.predict(xfts)
    auc = roc_auc_score(yts, yp)
    MLPC.append([g,auc])

MLPC_DF = pd.DataFrame(MLPC,columns=['CONF','AUC'])
MLPC_DF.sort_values('AUC',ascending=False,inplace=True)
MLP_OPT = MLPC_DF['CONF'].iloc[0]

# with open('OUTPUT/MLPC.pickle','wb') as f:
#       pickle.dump(MLPC_DF,f,pickle.HIGHEST_PROTOCOL)

#%% INICIALIZACION DE MODELOS

import pickle

LR_DF = pd.read_pickle('OUTPUT/LOGREG.pickle')
DT_DF = pd.read_pickle('OUTPUT/DTREE.pickle')
RF_DF = pd.read_pickle('OUTPUT/RFOREST.pickle')
MLP_DF = pd.read_pickle('OUTPUT/MLPC.pickle')

LR_OPT = LR_DF['CONF'].iloc[0]
DT_OPT = DT_DF['CONF'].iloc[0]
RF_OPT = RF_DF['CONF'].iloc[0]
MLP_OPT = MLP_DF['CONF'].iloc[0]


MODELS = {}

MODELS['logreg'] = LogisticRegression(penalty='elasticnet',solver='saga',
                                      l1_ratio=LR_OPT[0],C=LR_OPT[1],max_iter=LR_OPT[2],
                                      random_state=14,warm_start=True)
 
MODELS['dtree'] = DecisionTreeClassifier(criterion=DT_OPT[0],splitter=DT_OPT[1],min_samples_split=DT_OPT[2],
                                         min_samples_leaf=DT_OPT[3],random_state=14)
    
MODELS['forest'] = RandomForestClassifier(criterion=RF_OPT[0],n_estimators=int(RF_OPT[1]),min_samples_split=RF_OPT[2],
                                          min_samples_leaf=RF_OPT[3],random_state=14,warm_start=True)

MODELS['mlp'] = MLPClassifier(hidden_layer_sizes=(int(MLP_OPT[0]),),activation=MLP_OPT[1],solver=MLP_OPT[2],
                              learning_rate=MLP_OPT[3],max_iter=MLP_OPT[4],momentum=MLP_OPT[5],
                              random_state=14,early_stopping=True,warm_start=True)




#%% ENTRENAMIENTO 

# model.fit(xtraining, ytraining)

for m in list(MODELS.keys()):
    print(m,'...')
    MODELS[m].fit(xbtr,ybtr)

del(m)


#%% PREDICCIÓN CON LOS MODELOS

# p_training = model.predict(xtraining)
# p_testing = model.predict(xtesting)

PREDS = {}
for m in list(MODELS.keys()):
    print(m,'...')
    yptr = MODELS[m].predict(xbtr)
    ypts = MODELS[m].predict(xfts)
    PREDS[m] = {'train':yptr,'test':ypts}

del(yptr,ypts,m)

#%% METRICAS DE CLASIFICACION

# report_training = classification_report(ytraining,ptrainig)
# report_training = classification_report(ytesting,ptesting)

REPORTS = {}
for m in list(MODELS.keys()):
    print(m,'...')
    report_tr = classification_report(ybtr, PREDS[m]['train'],output_dict=False)
    report_ts = classification_report(yts, PREDS[m]['test'],output_dict=False)
    REPORTS[m] = {'train':report_tr,'test':report_ts}

del(report_tr,report_ts,m)

#%% APLANAR REPORTES DE CLASIFICACION

REPORTS = {}
AUC = {}
for m in list(MODELS.keys()):
    print(m,'...')
    report_tr = classification_report(ybtr, PREDS[m]['train'],output_dict=True)
    report_ts = classification_report(yts, PREDS[m]['test'],output_dict=True)
    auc_tr = roc_auc_score(ybtr, PREDS[m]['train'])
    auc_ts = roc_auc_score(yts, PREDS[m]['test'])
    REPORTS[m] = {'train':report_tr,'test':report_ts}
    AUC[m] = {'train':auc_tr,'test':auc_ts}


def FLATTEN(report_dict, auc, split_sample, model_name):
    split = split_sample
    
    pre_0 = report_dict['0']['precision']
    pre_1 = report_dict['1']['precision']
    
    rec_0 = report_dict['0']['recall']
    rec_1 = report_dict['1']['recall']
    
    f_0 = report_dict['0']['f1-score']
    f_1 = report_dict['1']['f1-score']
    
    s_0 = report_dict['0']['support']
    s_1 = report_dict['1']['support']
    
    acc = report_dict['accuracy']
    
    lista = [split,auc,acc,pre_0,pre_1,rec_0,rec_1,f_0,f_1,s_0,s_1]
    
    dfl = pd.DataFrame(lista)
    dfl.columns = [model_name]
    dfl.index = ['SPLIT','AUC','ACCURACY','PRECISION_0','PRECISION_1','RECALL_0','RECALL_1','F_0','F_1','SUPPORT_0','SUPPORT_1'] 
    dfl = dfl.T
    
    return dfl


F_REPORTS = []
for m in list(MODELS.keys()):
    
    r_tr = REPORTS[m]['train']
    r_ts = REPORTS[m]['test']
    auc_tr = AUC[m]['train']
    auc_ts = AUC[m]['test']
    
    fr_tr = FLATTEN(r_tr,auc_tr,'train',m)
    fr_ts = FLATTEN(r_ts,auc_ts,'test',m)
    
    F_REPORTS.append(fr_tr)
    F_REPORTS.append(fr_ts)

DFR = F_REPORTS[0]
for r in F_REPORTS[1:]:
    DFR = pd.concat([DFR,r],axis=0)

del(r,m,r_tr,r_ts,fr_tr,fr_ts,report_tr,report_ts)

DFR.to_excel('OUTPUT/Optimized_Results.xlsx')
