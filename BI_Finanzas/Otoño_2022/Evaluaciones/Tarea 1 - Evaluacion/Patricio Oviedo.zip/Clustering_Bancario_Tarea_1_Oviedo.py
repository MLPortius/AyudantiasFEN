# -*- coding: utf-8 -*-
"""
Created on Sun Jun 12 16:50:18 2022

@author: Patricio Oviedo
"""

import pandas as pd
import matplotlib.pyplot as plt

from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

#%% Cargar datos y escalar Datos

Data = pd.read_excel("creditos_bancarios.xlsx", sheet_name="SouthGermanCredit")

Escalar = StandardScaler()

DatosEscalados = Escalar.fit_transform(Data)

#%% Se crea modelo con metodo de clasificación con 5 muestras o clusters 
# 5 segmentos de clientes, segun lo solicitado en problema

Clusters = KMeans(n_clusters=5)

Clusters.fit(DatosEscalados)

Clusters_M = Clusters.labels_

#%% Estructuramos los datos para revisión

Clusters_M = pd.DataFrame(Clusters_M, columns=["variables"])

Resultado = pd.concat([Clusters_M, Data], axis=1)

Resultado.to_excel("resultado_clusters.xlsx")

#Silueta

silueta = silhouette_score(DatosEscalados, Clusters.labels_, metric='euclidean')
print(silueta)

#%% PRUEBA DE ALGORITMO CON SILUETA (CLUSTERS=20)

n_modelos = 20 
etiquetas = [] 

for i in range(2,n_modelos+1):
    Clusters1 = KMeans(n_clusters=i)    
    Clusters1.fit(DatosEscalados)             
    Clusters_M1 = Clusters.labels_     
    
    silueta_ = silhouette_score(DatosEscalados, Clusters1.labels_, metric='euclidean')
    
    etiquetas.append([i,Clusters_M1,silueta_]) # Almaceno los resultados en la libreria etiquetas
    
    print("Cluster: "+str(i))
    print("Silueta: "+str(silueta_))
    
#%% Seleccionamos los datos con los Cluster óptimos y lo anexamos a la Data Original para un correcto analisis

Cluster_Optimos = etiquetas[5][1]  # Selecciono las etiquetas del modelo optimo (5 para la mayoria de las iteraciones)

Cluster_Optimos = pd.DataFrame(Cluster_Optimos,
                                columns=['variables'])   # Le ponemos nombre a la fila de Clusters

Resultado_Optimo = pd.concat([Cluster_Optimos, Data], axis=1)   # Pegamos los Clusters a la tabla de data original

Resultado_Optimo.to_excel('resultado_optimo_clustering.xlsx')   # Exporto a Excel

estados = Resultado_Optimo.describe()

estados_por_variable = Resultado_Optimo.groupby("variables").mean()  
