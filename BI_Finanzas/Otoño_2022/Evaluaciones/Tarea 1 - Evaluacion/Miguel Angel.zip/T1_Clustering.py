# -*- coding: utf-8 -*-
"""
Created on Sat Jun 11 20:46:14 2022

@author: FMIG
"""

#%% Importar librerias

import pandas as pd
import numpy as np
#import matplotlib.pylot as plt

from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

#%% Carga de datos y estandarizacion

Data = pd.read_excel('creditos_bancarios.xlsx', sheet_name='SouthGermanCredit')
purpose = Data.loc[:,'purpose']                         #Extraemos la columna 'purpose'
purpose_proc = pd.get_dummies(purpose,prefix='purpose') #Preprocesamos la columna 'purpose'
Data = Data.drop('purpose',axis=1)                      #Eliminamos la columna 'purpose' del Dataframe
Data = pd.concat([Data,purpose_proc],axis=1)            #Concatenamos la columna 'purpose_proc' al Dataframe

cred_hist = Data.loc[:,'credit_history']                         #Extraemos la columna 'credit_history'
cred_hist_proc = pd.get_dummies(cred_hist,prefix='credit_history') #Preprocesamos la columna 'credit_history'
Data = Data.drop('credit_history',axis=1)                      #Eliminamos la columna 'credit_history' del Dataframe
Data = pd.concat([Data,cred_hist_proc],axis=1)            #Concatenamos la columna 'cred_hist_proc' al Dataframe

Scaler = StandardScaler()                               #Crea un escalador
DataNorm = Scaler.fit_transform(Data)                   #Se escalan los datos

#%% ALGORITMO DE CLUSTERING - 30 MODELOS K CLUSTERS

n_modelos = 30 # Defino la cantidad de clusteres maximos a probar
etiquetas = [] # Creo una lista para guardar los resultados tras cada iteracion

for i in range(2,n_modelos+1):
    Kmeans_M0 = KMeans(n_clusters=i)    # Creo modelo de KMeans  
    Kmeans_M0.fit(DataNorm)             # Aplica el kmeans a la data escalada
    Clusters_M0 = Kmeans_M0.labels_     # Obtiene las etiquetas de cluster
    
    silueta = silhouette_score(DataNorm, Kmeans_M0.labels_, metric='euclidean')
    
    etiquetas.append([i,Clusters_M0,silueta]) # Almaceno los resultados
    
    print("Cluster: "+str(i))
    print("Silueta: "+str(silueta))
    
Cluster_Optimo = etiquetas[18][1]  # Selecciono las etiquetas del modelo optimo
Cluster_Optimo = pd.DataFrame(Cluster_Optimo,
                                columns=['etiqueta_cluster'])   # Doy formato DataFrame

Resultado_Optimo = pd.concat([Cluster_Optimo, Data], axis=1)   # Pega la columnas con la tabla

Resultado_Optimo.to_excel('resultado_optimo_clustering.xlsx')   # Exporto a Excel


# Genero tablas para interpretar clusters:
estados_opt = Resultado_Optimo.describe() 
estados_opt_por_cluster = Resultado_Optimo.groupby('etiqueta_cluster').mean()       # Promedios de Caracteristicas por Cluster
estados_opt_por_cluster_n = Resultado_Optimo.groupby('etiqueta_cluster').count()    # Cantidad de Individuos por Cluster
