# -*- coding: utf-8 -*-
"""
Created on Sat Jun 11 20:46:14 2022

@author: FMIG
"""

#%% IMPORTACIÓN DE LIBRERÍAS

import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report

from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier

#%% CARGA DE DATOS

Data = pd.read_excel('creditos_bancarios.xlsx', sheet_name='SouthGermanCredit')
seed = 14   #Establecer semilla

#%% PREPROCESAMIENTO DE DATOS

def PREPROCESS_DATA(DATABASE, TRAINING):
    purpose = DATABASE.loc[:,'purpose']                          #Extraemos la columna 'purpose'
    purpose_proc = pd.get_dummies(purpose,prefix='purpose')      #Preprocesamos la columna 'purpose'
    DATABASE = DATABASE.drop('purpose',axis=1)                   #Eliminamos la columna 'purpose' del Dataframe
    DATABASE = pd.concat([purpose_proc,DATABASE],axis=1)         #Concatenamos la columna 'purpose_proc' al Dataframe
    
    cred_hist_map = {0:0,1:0,2:1,3:1,4:1}                        #Reclasificamos la columna 'credit_history' como 0: Mal historial crediticio y 1: Buen historial crediticio
    DATABASE.loc[:,'credit_history'] = DATABASE.loc[:,'credit_history'].map(cred_hist_map) #Poblamos el campo 'credit_history' con la nueva clasificación

    if (TRAINING==True):
        xdata = DATABASE.iloc[:,:len(DATABASE.columns)-1]
        ydata = DATABASE.iloc[:,-1]
    else:
        xdata = DATABASE
        
    if (TRAINING==True):
        return ydata, xdata
    else:
        return xdata

#Aplico función
Y, X = PREPROCESS_DATA(Data, True)

#%% SEPARACIÓN TRAIN TEST

X_tr, X_ts, Y_tr, Y_ts = train_test_split(X,Y,test_size=0.2,random_state=seed)

#%% ESTANDARIZACIÓN DE DATOS

#Crea un escalador
scaler = StandardScaler()

# Escalar X_train a Zscore
Xs_tr = scaler.fit_transform(X_tr)
    
# Dar Formato DataFrame
Xs_tr = pd.DataFrame(Xs_tr)
Xs_tr.columns = X_tr.columns
Xs_tr.index = X_tr.index

# Escalar X_test a Zscore
Xs_ts = scaler.transform(X_ts)

# Dar Formato DataFrame
Xs_ts = pd.DataFrame(Xs_ts)
Xs_ts.columns = X_ts.columns
Xs_ts.index = X_ts.index

#%% BALANCEO DE CLASES

print("Balance de Clases Training Original: ")
Y_tr.value_counts()/len(Y_tr)*100

# Compilar Datos X e Y
XY_tr = pd.concat([Y_tr,Xs_tr],axis=1)

# Oversampling
XY_tr_1 = XY_tr.loc[XY_tr['credit_risk']==1,:] # Datos a alcanzar
XY_tr_0 = XY_tr.loc[XY_tr['credit_risk']==0,:] # Datos a ampliar

# Veces a ampliar (Cantidad a Alcanzar / Cantidad a Duplicar)
k = len(XY_tr_1.index)/len(XY_tr_0.index)

# Cantidad de datos finales
n = len(XY_tr_1.index)

# Sintesis de Datos
XYb_tr_0 = XY_tr_0.sample(n, replace=True, random_state=seed, axis=0)

# Concatenar datos hacia abajo
XYb_tr = pd.concat([XY_tr_1,XYb_tr_0],axis=0)

# Separar datos nuevamente
Yb_tr = XYb_tr.iloc[:,0]
Xsb_tr = XYb_tr.iloc[:,1:]

print("Balance de Clases Training Oversampled: ")
Yb_tr.value_counts()/len(Yb_tr)*100

#%% ENTRENAMIENTO DE MODELO REGRESIÓN LOGÍSTICA

#Configuración del modelo
LOG = LogisticRegression(penalty="none",fit_intercept=True, random_state=seed,
                         max_iter=1000,verbose=1)

#Entrenamiento del modelo
LOG.fit(Xsb_tr,Yb_tr)

#Aplicación del modelo
Yp_tr = LOG.predict(Xs_tr)
Yp_ts_LOG = LOG.predict(Xs_ts)

#%% ENTRENAMIENTO DE MODELO RANDOM FOREST

#Configuración del modelo
RDMF = RandomForestClassifier(n_estimators=100,criterion='gini',
                              random_state=seed,verbose=1)

#Entrenamiento del modelo
RDMF.fit(Xsb_tr,Yb_tr)

#Aplicación del modelo
Yp_tr = RDMF.predict(Xs_tr)
Yp_ts_RDMF = RDMF.predict(Xs_ts)

#%% ENTRENAMIENTO DE MODELO RED NEURONAL

#Configuración del modelo
NN = MLPClassifier(hidden_layer_sizes=(516,),activation='relu',
                   solver='adam', alpha=0.025, random_state=seed,
                   verbose=1, max_iter=1000,warm_start=True,early_stopping=False)

#Entrenamiento del modelo
NN.fit(Xsb_tr,Yb_tr)

#Aplicación del modelo
Yp_tr = NN.predict(Xs_tr)
Yp_ts_NN = NN.predict(Xs_ts)

#%% REPORTES DE CLASIFICACIÓN

print("Modelo Regresión Logística Testing")
print(classification_report(Y_ts, Yp_ts_LOG))
#print("Modelo Regresión Logística Training")
#print(classification_report(Y_tr, Yp_tr))

print("Modelo Random Forest Testing")
print(classification_report(Y_ts, Yp_ts_RDMF))
#print("Modelo Random Forest Training")
#print(classification_report(Y_tr, Yp_tr))

print("Modelo Red Neuronal Testing")
print(classification_report(Y_ts, Yp_ts_NN))
#print("Modelo Red Neuronal Training")
#print(classification_report(Y_tr, Yp_tr))

#%% RESULTADOS MODELO

creditos_data = pd.read_excel('creditos_bancarios_new.xlsx', sheet_name='SouthGermanCredit')
print(creditos_data)

# PREPARAR DATOS
creditos_x = PREPROCESS_DATA(creditos_data, False)

# APLICACION DE MODELO
#creditos_yp = RDMF.predict(creditos_x)
creditos_yp = LOG.predict(creditos_x)

# ETIQUETACIÓN DE CLASE
creditos = creditos_x
creditos["Credit Risk (Yp)"] = creditos_yp

# EXPORTAR RESULTADO A EXCEL
creditos.to_excel("Creditos_AnalisisCreditRisk.xlsx")