# -*- coding: utf-8 -*-
"""
Created on Tue Jun 14 15:17:50 2022

@author: Andriu
"""

#%% IMPORTAR LIBRERIAS
import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report

from sklearn.linear_model import LogisticRegression
from sklearn.linear_model import SGDClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier

#%% CARGA DE DATOS
fuga_data = pd.read_excel("fuga_ampliada.xlsx")
clientes_data = pd.read_excel("cartera_ampliada.xlsx")

seed = 14

#%% LIMPIEZA DE DATOS

def PREPROCESS_FUGA(DATA, zona, genero, fuga, TRAINING):
    #Definir indice y separar data
    indID = DATA.columns[0] 
    DATA.set_index(indID,drop=True,inplace=True)
    if (TRAINING==True):
        xdata = DATA.iloc[:,:len(DATA.columns)-1]
        ydata = DATA.iloc[:,-1]
        ydata = ydata.map(fuga) 
    else:
        xdata = DATA
        
    #Aplicar MAPPINGS
    xdata["ZonaGeografica"] = xdata["ZonaGeografica"].map(zona)
    xdata["Genero"] = xdata["Genero"].map(genero)

    #One Hot Encoding
    OHE = pd.get_dummies(xdata['Proposito'],prefix="Pr")
    OHE = OHE.astype('int')
    xdata.drop("Proposito",axis=1,inplace=True)
    xdata = pd.concat([xdata,OHE],axis=1)
    
    if (TRAINING==True):
        return ydata, xdata
    else:
        return xdata

#Generar MAPPINGS
zona_map = {"Sur":0, "Centro":50, "Norte":100}
genero_map = {"Mujer":0,"Hombre":1}
fuga_map = {"No":0, "Si":1}

#Aplico FUNCION
Y, X = PREPROCESS_FUGA(fuga_data, zona_map, genero_map, fuga_map, True)

#%% SEPARACIÓN TRAIN TEST

X_tr, X_ts, Y_tr, Y_ts = train_test_split(X,Y,test_size=0.2,random_state=seed)


#%% ESTANDARIZACIÓN DE DATOS

scaler = StandardScaler()

# Escalar X_train a Zscore
Xs_tr = scaler.fit_transform(X_tr)
    
# Dar Formato DataFrame
Xs_tr = pd.DataFrame(Xs_tr)
Xs_tr.columns = X_tr.columns
Xs_tr.index = X_tr.index


# Escalar X_test a Zscore
Xs_ts = scaler.transform(X_ts)

# Dar Formato DataFrame
Xs_ts = pd.DataFrame(Xs_ts)
Xs_ts.columns = X_ts.columns
Xs_ts.index = X_ts.index

#%% BALANCEO DE CLASES

print("Balance de Clases Training Original: ")
Y_tr.value_counts()/len(Y_tr)*100

# Compilar Datos X e Y
XY_tr = pd.concat([Y_tr,Xs_tr],axis=1)

# Oversampling
XY_tr_1 = XY_tr.loc[XY_tr['Fugado']==1,:] # Datos a ampliar
XY_tr_0 = XY_tr.loc[XY_tr['Fugado']==0,:] # Datos a alcanzar

# Veces a ampliar (Cantidad a Alcanzar / Cantidad a Duplicar)
k = len(XY_tr_0.index)/len(XY_tr_1.index)

# Cantidad de datos finales
n = len(XY_tr_0.index)

# Sintesis de Datos
XYb_tr_1 = XY_tr_1.sample(n, replace=True, random_state=seed, axis=0)

# Concatenar datos hacia abajo
XYb_tr = pd.concat([XY_tr_0,XYb_tr_1],axis=0)

# Separar datos nuevamente
Yb_tr = XYb_tr.iloc[:,0]
Xsb_tr = XYb_tr.iloc[:,1:]

print("Balance de Clases Training Oversampled: ")
Yb_tr.value_counts()/len(Yb_tr)*100



#%% ENTRENAMIENTO DE MODELO REGRESION LOGÍSTICA

#CONFIGURACION DE MODELO
LOG = LogisticRegression(penalty="none",fit_intercept=True, random_state=seed,
                         max_iter=1000,verbose=0)

#ENTRENAMIENTO DE MODELO
LOG.fit(Xsb_tr,Yb_tr)

#APLICACION DEL MODELO
Yp_tr = LOG.predict(Xs_tr)
Yp_ts_LOG = LOG.predict(Xs_ts)

#%% ENTRENAMIENTO DE MODELO GRADIENTE DESCENDIENTE ESTOCASTICO

#CONFIGURACION DE MODELO
SGD = SGDClassifier(loss="hinge",penalty="none",alpha=0.001,fit_intercept=True, 
                    max_iter=1000,random_state=seed,verbose=1)

#ENTRENAMIENTO DE MODELO
SGD.fit(Xsb_tr,Yb_tr)

#APLICACION DE MODELO
Yp_tr = SGD.predict(Xs_tr)
Yp_ts_SGD = SGD.predict(Xs_ts)

#%% ENTRENAMIENTO DE MODELO RANDOM FOREST

#CONFIGURACION DE MODELO
RDMF = RandomForestClassifier(n_estimators=100,criterion='gini',
                              random_state=seed,verbose=1)

#ENTRENAMIENTO DE MODELO
RDMF.fit(Xsb_tr,Yb_tr)

#APLICACION DE MODELO
Yp_tr = RDMF.predict(Xs_tr)
Yp_ts_RDMF = RDMF.predict(Xs_ts)


#%% ENTRENAMIENTO DE MODELO RED NEURONAL

#CONFIGURACION DE MODELO
NN = MLPClassifier(hidden_layer_sizes=(516,),activation='relu',
                   solver='adam', alpha=0.025, random_state=seed,
                   verbose=1, max_iter=1000,warm_start=True,early_stopping=False)

#ENTRENAMIENTO DE MODELO
NN.fit(Xsb_tr,Yb_tr)

#APLICACION DE MODELO
Yp_tr = NN.predict(Xs_tr)
Yp_ts_NN = NN.predict(Xs_ts)

#%% REPORTES DE CLASIFICACIÓN

print("Modelo Regresión Logistica")
print(classification_report(Y_ts, Yp_ts_LOG))

print("Modelo Gradiente Descendiente Estocastico")
print(classification_report(Y_ts, Yp_ts_SGD))

print("Modelo Random Forest")
print(classification_report(Y_ts, Yp_ts_RDMF))

print("Modelo Neural Network")
print(classification_report(Y_ts, Yp_ts_NN))


#%% CONTRASTE PROYECTO ANTERIOR

print(clientes_data)

# PREPARAR DATOS
clientes_x = PREPROCESS_FUGA(clientes_data,zona_map, genero_map, fuga_map, False)

# APLICACION DE MODELO
clientes_yp = RDMF.predict(clientes_x)

# ETIQUETACIÓN DE CLASE
clientes = clientes_x
clientes["FUGA (Yp)"] = clientes_yp

# EXPORTAR RESULTADO A EXCEL
clientes.to_excel("Clientes_AnalisisFuga.xlsx")





