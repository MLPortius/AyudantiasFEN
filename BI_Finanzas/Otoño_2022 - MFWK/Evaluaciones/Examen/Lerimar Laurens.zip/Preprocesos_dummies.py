# -*- coding: utf-8 -*-
"""
Created on Sun Jun 12 21:43:17 2022

@author: OsvaldoCaraccioli
"""
import pandas as pd

df=pd.read_excel('creditos_bancarios.xlsx',sheet_name='SouthGermanCredit')

purpose=df.loc[:,'purpose']

proposito=pd.get_dummies(purpose)

#%%

df=pd.read_excel('creditos_bancarios.xlsx',sheet_name='SouthGermanCredit')

personal_status_sex=df.loc[:,'personal_status_sex']

estado_civil=pd.get_dummies(personal_status_sex)

#%%

df=pd.read_excel('creditos_bancarios.xlsx',sheet_name='SouthGermanCredit')

other_debtors=df.loc[:,'other_debtors']

debtors=pd.get_dummies(other_debtors)

#%%

df=pd.read_excel('creditos_bancarios.xlsx',sheet_name='SouthGermanCredit')

other_installment_plans=df.loc[:,'other_installment_plans']

other_installment_plans=pd.get_dummies(other_installment_plans)

#%%

df=pd.read_excel('creditos_bancarios.xlsx',sheet_name='SouthGermanCredit')

housing=df.loc[:,'housing']

housing=pd.get_dummies(housing)










