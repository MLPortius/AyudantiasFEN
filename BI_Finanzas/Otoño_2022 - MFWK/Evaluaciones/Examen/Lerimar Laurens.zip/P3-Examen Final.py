# -*- coding: utf-8 -*-
"""
Created on Wed Jul  6 15:05:00 2022

@author: OsvaldoCaraccioli
"""

#%% IMPORTAR LIBRERIAS
import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report

from sklearn.linear_model import LogisticRegression
from sklearn.linear_model import SGDClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier

#%% CARGA DE DATOS
data0=pd.read_excel('creditos_bancarios.xlsx')
data=data0.dropna()
seed = 42

#%%

Y=data["credit_risk"]
X=data.iloc[:,1:]


#%% SEPARACIÓN TRAIN TEST
#Aplico funcion de preproceso para ENTRENAR


X_tr, X_ts, Y_tr, Y_ts = train_test_split(X,Y,test_size=0.3,random_state=seed)


#%% ESTANDARIZACIÓN DE DATOS

scaler = StandardScaler()

# Escalar X_train a Zscore
Xs_tr = scaler.fit_transform(X_tr)
    
# Dar Formato DataFrame
Xs_tr = pd.DataFrame(Xs_tr)
Xs_tr.columns = X_tr.columns
Xs_tr.index = X_tr.index


# Escalar X_test a Zscore
Xs_ts = scaler.transform(X_ts)

# Dar Formato DataFrame
Xs_ts = pd.DataFrame(Xs_ts)
Xs_ts.columns = X_ts.columns
Xs_ts.index = X_ts.index

#%% BALANCEO DE CLASES

print("Balance de Clases Training Original: ")
Y_tr.value_counts()/len(Y_tr)*100

# Compilar Datos X e Y
XY_tr = pd.concat([Y_tr,Xs_tr],axis=1)

# Oversampling
XY_tr_1 = XY_tr.loc[XY_tr['credit_risk']==1,:] # Datos a ampliar
XY_tr_0 = XY_tr.loc[XY_tr['credit_risk']==0,:] # Datos a alcanzar

# Veces a ampliar (Cantidad a Alcanzar / Cantidad a Duplicar)
k = len(XY_tr_0.index)/len(XY_tr_1.index)

# Cantidad de datos finales
n = len(XY_tr_0.index)

# Sintesis de Datos
XYb_tr_1 = XY_tr_1.sample(n, replace=True, random_state=seed, axis=0)

# Concatenar datos hacia abajo
XYb_tr = pd.concat([XY_tr_0,XYb_tr_1],axis=0)

# Separar datos nuevamente
Yb_tr = XYb_tr.iloc[:,0]
Xsb_tr = XYb_tr.iloc[:,1:]

print("Balance de Clases Training Oversampled: ")
Yb_tr.value_counts()/len(Yb_tr)*100



#%% ENTRENAMIENTO DE MODELO REGRESION LOGÍSTICA

#CONFIGURACION DE MODELO
LOG = LogisticRegression(penalty="none",fit_intercept=True, random_state=seed,
                         max_iter=1000,verbose=0)

#ENTRENAMIENTO DE MODELO
LOG.fit(Xsb_tr,Yb_tr)

#APLICACION DEL MODELO
Yp_tr = LOG.predict(Xs_tr)
Yp_ts_LOG = LOG.predict(Xs_ts)


#%% ENTRENAMIENTO DE MODELO GRADIENTE DESCENDIENTE ESTOCASTICO

#CONFIGURACION DE MODELO
SGD = SGDClassifier(loss="hinge",penalty="none",alpha=0.001,fit_intercept=True, 
                    max_iter=1000,random_state=seed,verbose=1)

#ENTRENAMIENTO DE MODELO
SGD.fit(Xsb_tr,Yb_tr)

#APLICACION DE MODELO
Yp_tr = SGD.predict(Xs_tr)
Yp_ts_SGD = SGD.predict(Xs_ts)

#%% ENTRENAMIENTO DE MODELO RANDOM FOREST

#CONFIGURACION DE MODELO
RDMF = RandomForestClassifier(n_estimators=100,criterion='gini',
                              random_state=seed,verbose=1)

#ENTRENAMIENTO DE MODELO
RDMF.fit(Xsb_tr,Yb_tr)

#APLICACION DE MODELO
Yp_tr = RDMF.predict(Xs_tr)
Yp_ts_RDMF = RDMF.predict(Xs_ts)


#%% ENTRENAMIENTO DE MODELO RED NEURONAL

#CONFIGURACION DE MODELO
NN = MLPClassifier(hidden_layer_sizes=(516,),activation='relu',
                   solver='adam', alpha=0.025, random_state=seed,
                   verbose=1, max_iter=1000,warm_start=True,early_stopping=False)

#ENTRENAMIENTO DE MODELO
NN.fit(Xsb_tr,Yb_tr)

#APLICACION DE MODELO
Yp_tr = NN.predict(Xs_tr)
Yp_ts_NN = NN.predict(Xs_ts)

#%% REPORTES DE CLASIFICACIÓN

print("Modelo Regresión Logistica")
print(classification_report(Y_ts, Yp_ts_LOG))

print("Modelo Gradiente Descendiente Estocastico")
print(classification_report(Y_ts, Yp_ts_SGD))

print("Modelo Random Forest")
print(classification_report(Y_ts, Yp_ts_RDMF))

print("Modelo Neural Network")
print(classification_report(Y_ts, Yp_ts_NN))

#%%  MODELO REGRESION LOGISTICA 

VARIABLES = LOG.n_features_in_

COEFICIENTES = LOG.coef_
COEFICIENTES = COEFICIENTES.transpose()
COEFICIENTES = pd.DataFrame(COEFICIENTES)
LOGISTICA = pd.concat([pd.Series(VARIABLES),COEFICIENTES],axis = 1)
LOGISTICA.to_excel("LOGISTICA.xlsx")
