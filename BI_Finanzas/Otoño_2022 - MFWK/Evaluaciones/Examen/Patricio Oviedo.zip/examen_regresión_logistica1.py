# -*- coding: utf-8 -*-
"""
Created on Tue Jul  5 23:38:16 2022

@author: Patricio Oviedo
"""

import pandas as pd

data=pd.read_excel("creditos_bancarios.xlsx", sheet_name="SouthGermanCredit")

Y=data["credit_risk"]
X=data.iloc[:,:-1]



#%% Creamos la data de Train y Test

from sklearn.model_selection import train_test_split

X_train, X_test, Y_train, Y_test = train_test_split(X,Y, test_size=0.30, random_state=42)

#%% Normalizamos la data

from sklearn.preprocessing import StandardScaler
escalar = StandardScaler()

escalar.fit(X_train)

X_train_std = escalar.transform(X_train)
X_train_std=pd.DataFrame(data=X_train_std, columns=X_train.columns, index=X_train.index)

X_test_std = escalar.transform(X_test)

X_test_std=pd.DataFrame(data=X_test_std, columns=X_test.columns, index=X_test.index)


#%% Aplicamos modelo Regresión

from sklearn.linear_model import LogisticRegression

reg_logistica = LogisticRegression(penalty="none")

reg_logistica.fit(X_train_std, Y_train)

y_pred_train = reg_logistica.predict(X_train_std)

y_pred_train = pd.DataFrame(y_pred_train, columns=["Y_Predicha"], index=Y_train.index)

# Para Y test.


y_pred_test = reg_logistica.predict(X_test_std)

y_pred_test = pd.DataFrame(y_pred_test, columns=["Y_Predicha_test"], index=Y_test.index)


#%% Reporte de clasificación

from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix

print("Resultado en Muestra de entrenamiento")

print(classification_report(Y_train, y_pred_train))

print(confusion_matrix(Y_train, y_pred_train))

print("Resultado en Muestra de test")

print(classification_report(Y_test, y_pred_test))

print(confusion_matrix(Y_test, y_pred_test))




