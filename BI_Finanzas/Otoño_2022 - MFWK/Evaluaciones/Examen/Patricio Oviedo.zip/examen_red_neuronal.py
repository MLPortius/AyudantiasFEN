# -*- coding: utf-8 -*-
"""
Created on Tue Jul  5 23:38:16 2022

@author: Patricio Oviedo
"""

import pandas as pd

data=pd.read_excel("creditos_bancarios.xlsx", sheet_name="SouthGermanCredit")

Y=data["credit_risk"]
X=data.iloc[:,:-1]

#%% Creamos la data de Train y Test

from sklearn.model_selection import train_test_split

X_train, X_test, Y_train, Y_test = train_test_split(X,Y, test_size=0.30, random_state=42)

#%% Normalizamos la data

from sklearn.preprocessing import StandardScaler
escalar = StandardScaler()

escalar.fit(X_train)

X_train_std = escalar.transform(X_train)
X_train_std=pd.DataFrame(data=X_train_std, columns=X_train.columns, index=X_train.index)

X_test_std = escalar.transform(X_test)

X_test_std=pd.DataFrame(data=X_test_std, columns=X_test.columns, index=X_test.index)


#%% Balanceo de Data

#Para Train

data.credit_risk.value_counts()
Y_train.value_counts()

Y_train_Paga=Y_train[Y_train==1]
Y_train_No_Paga=Y_train[Y_train==0]

Y_train_No_Paga=Y_train_No_Paga.sample(len(Y_train_Paga),replace=True, random_state=13)


Y_train=pd.concat([Y_train_Paga,Y_train_No_Paga],axis=0)
Y_train.value_counts()


X_train_std=X_train_std.loc[Y_train.index,:]
len(X_train_std)


#%% Aplicamos modelo red neuronal para Y_train e Y_test

from sklearn.neural_network import MLPClassifier

mlp=MLPClassifier(alpha=0,hidden_layer_sizes=(5,5),activation='relu')

mlp.fit(X_train_std,Y_train)


y_pred_train=mlp.predict(X_train_std)
y_pred_train=pd.DataFrame(y_pred_train,columns=["Y_predicha"],index=Y_train.index)
y_pred_train

y_pred_test=mlp.predict(X_test_std)
y_pred_test=pd.DataFrame(y_pred_test,index=Y_test.index,columns=["Y_predicha"])
y_pred_test



#%% Reporte de clasificación

from sklearn.metrics import classification_report

print("Resultado en Muestra de entrenamiento")

print(classification_report(Y_train, y_pred_train))

print("Resultado en Muestra de test")

print(classification_report(Y_test, y_pred_test))

print(data.credit_risk.value_counts())

from sklearn.metrics import confusion_matrix

print(confusion_matrix(Y_train, y_pred_train))

print(confusion_matrix(Y_test, y_pred_test))

