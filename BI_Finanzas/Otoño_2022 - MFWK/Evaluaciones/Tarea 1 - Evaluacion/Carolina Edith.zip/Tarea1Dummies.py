# -*- coding: utf-8 -*-
"""
Created on Sun Jun 12 16:13:37 2022

@author: aguil
"""
#%% A) PROCESAMIENTO DE DATOS


#%% 1. Instalación e Importación de Librerías necesarias

import pandas as pd
import numpy as np

from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.metrics import calinski_harabasz_score
import matplotlib.pyplot as plt


#%% 2. Entendimiento y carga de Datos a Python

Credit = pd.read_excel('creditos_bancarios.xlsx', sheet_name='SouthGermanCredit')

CreditDesc = Credit.describe()



#%%

Credit.hist(figsize=(20,14))
plt.show()

plt.scatter(Credit.amount,Credit.age,color='purple',s=5)
plt.xlabel('Amount_1')
plt.ylabel('Age_1')
plt.show()


Credit_0 = pd.get_dummies(Credit,columns=['purpose'])
Credit_a = Credit_0.drop(['duration'], axis=1)


#%% 3. Preparación y Preproceso del Dataset

# Estandarización de Credit

Scaler = StandardScaler()          
Credit_a_Stan = pd.DataFrame(Scaler.fit_transform(Credit_a),columns = Credit_a.columns, index =Credit.index)  # código pra realizar el escalamiento de los datos de la base Credit
Credit_a_StanDesc= Credit_a_Stan.describe()

# Análisis de los resultados

#%% B) DETERMINACION OPTIMA DE LOS CLUSTERS

#%% 4. Set-Up del Modelo seleccionado

#%% METODO ASIGNACION  K=4

# Modelo de clustering kmeans k=4

modelo_clustering4 = KMeans(n_clusters=4, random_state=10, n_init=10).fit(Credit_a_Stan)
etiquetas4=modelo_clustering4.predict(Credit_a_Stan)
etiquetas4

# Evaluación de los Cluster K=4
silueta4=silhouette_score(Credit_a_Stan, modelo_clustering4.labels_,metric='euclidean')
print(silueta4)

#%% METODO ASIGNACION DE K=5

# Modelo de clustering kmeans k=5

modelo_clustering5 = KMeans(n_clusters=5, random_state=10, n_init=10).fit(Credit_a_Stan)

etiquetas5=modelo_clustering5.predict(Credit_a_Stan)
etiquetas5

# Evaluación de los Cluster k=5
silueta5=silhouette_score(Credit_a_Stan, modelo_clustering5.labels_,metric='euclidean')
print(silueta5)

#%% METODO DEL CODO

# Definición de los clúste
distorsionsCodo = []
max_loopcodo=20
for k in range(2, max_loopcodo):
    kmeans = KMeans(n_clusters=k)
    kmeans.fit(Credit_a_Stan)
    distorsionsCodo.append(kmeans.inertia_)
    
# Gráfico del Codo   
figCodo = plt.figure(figsize=(15, 5))
plt.plot(range(2, max_loopcodo), distorsionsCodo)
plt.xticks([i for i in range(2, max_loopcodo)], rotation=75)
plt.grid(True)


#%% METODO SILUETA

# Definición de los Clúster a probar

max_loopS = 20 
Silueta_Score = []
Silueta_Score2 = []
for i in range(2,max_loopS):
    Kmeans_M0 = KMeans(n_clusters=i, random_state=10, n_init=10)   #lo tengo calculado por separado **   
    Kmeans_M0.fit(Credit_a_Stan)
    Clusters_M0 = Kmeans_M0.labels_ 
    Clusters_M0 = pd.DataFrame(Clusters_M0,columns=['etiqueta_cluster']) 
    # Evaluación de la siluetas de los cluster
    siluetas = silhouette_score(Credit_a_Stan, Kmeans_M0.labels_, metric='euclidean', random_state=10)
    Silueta_Score.append(siluetas)
    Silueta_Score2.append([i,Clusters_M0,siluetas])
    print("Cluster: "+str(i))
    print("Silueta: "+str(siluetas))
    
    #%%
    # Gráfico de la Silueta
    
figSilu = plt.figure(figsize=(15, 5))
plt.plot(range(2, max_loopS), Silueta_Score)
plt.xticks([k for k in range(2, max_loopS)], rotation=75)
plt.grid(True) 

ModeloCasteringS =KMeans(n_clusters=i, random_state=10, n_init=10).fit(Credit_a_Stan) 
ch = calinski_harabasz_score(Credit_a_Stan, ModeloCasteringS.labels_)   
cH

#%%  5. Selección Cluster Optimo 
    
Cluster_Optimos = Silueta_Score2[13][1]
#Cluster_Optimos.to_excel('Cluster_OptimosCreditoptimo.xlsx') para comprobar
Resultado_Optimo = pd.concat([Cluster_Optimos, Credit_a],axis=1)
Resultado_Optimo.to_excel('resultado_clusteringCreditoptimo.xlsx')
Resultado_OptimoDesc = Resultado_Optimo.describe()
Resultado_Optimo


#%%
#creo la matriz de centroides para cada cluster, ie. la media por cluster
centroides1=Resultado_Optimo.groupby('etiqueta_cluster').mean()
centroides1=centroides1.reset_index(drop=False)
#%%
#lo mismo pero para data escalada
Resultado_OptimoEsc = pd.concat([Cluster_Optimos, Credit_a_Stan],axis=1)
centroides2=Resultado_OptimoEsc.groupby('etiqueta_cluster').mean()
centroides2=centroides2.reset_index(drop=False)
#%%
centroides1

centroides2

