#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jun 15 21:16:30 2022

@author: leri
"""


##Librerias a utilizar

import pandas as pd
import numpy as np

from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

#%%

##Carga de Dataset y estandarización

Dataset=pd.read_excel("creditos_bancarios_6variables.xlsx", sheet_name="SouthGermanCredit")

Scaler = StandardScaler()               
DataNorm = Scaler.fit_transform(Dataset)   

#%%

##Entrenamiento de modelo

Kmeans_M0 = KMeans(n_clusters=5)    

Kmeans_M0.fit(DataNorm)             

Clusters_M0 = Kmeans_M0.labels_     

#%%

##Orden de clusters y análisis

Clusters_M0 = pd.DataFrame(Clusters_M0,columns=['Grupo_cluster'])

Resultado = pd.concat([Clusters_M0, Dataset],axis=1)      

Resultado.to_excel('resultado_clustering.xlsx')

estads = Resultado.describe() 
estads_por_cluster = Resultado.groupby('Grupo_cluster').mean()       
estads_por_cluster_n = Resultado.groupby('Grupo_cluster').count()    

#%%

##Modelo de Silueta

silueta_M0 = silhouette_score(DataNorm, Kmeans_M0.labels_, metric='euclidean')
print(silueta_M0)

#%%

##10 modelos de Silueta

n_modelos = 10
etiquetas = [] 

for i in range(2,n_modelos+1):
    Kmeans_M0 = KMeans(n_clusters=i)    
    Kmeans_M0.fit(DataNorm)             
    Clusters_M0 = Kmeans_M0.labels_    
    
    silueta = silhouette_score(DataNorm, Kmeans_M0.labels_, metric='euclidean')

    etiquetas.append([i,Clusters_M0,silueta]) 

    print("Cluster: "+str(i))
    print("Silueta: "+str(silueta))
    
#%%

##Selección y análisis del modelo óptimo
    
Cluster_Optimos = etiquetas[0][1]  

Cluster_Optimos = pd.DataFrame(Cluster_Optimos,columns=['Grupo_cluster'])

Resultado_Optimo = pd.concat([Cluster_Optimos, Dataset], axis=1)   

Resultado_Optimo.to_excel('resultado_optimo_clustering.xlsx')   

estads = Resultado_Optimo.describe() 
estads_por_cluster = Resultado_Optimo.groupby('Grupo_cluster').mean()       
estads_por_cluster_n = Resultado_Optimo.groupby('Grupo_cluster').count()    


