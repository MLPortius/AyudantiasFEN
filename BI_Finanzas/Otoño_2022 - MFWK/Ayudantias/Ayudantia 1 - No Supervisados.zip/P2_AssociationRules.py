# -*- coding: utf-8 -*-
"""
Created on Thu May 26 18:55:31 2022

@author: Andriu
"""

#%% LIBRERIAS

import pandas as pd
from mlxtend.frequent_patterns import apriori                # Carga libreria de patrones frecuentes apriori
from mlxtend.frequent_patterns import association_rules      # Carga libreria reglas de asociación

#%% CARGA DE DATOS

basket_sets = pd.read_csv('basket_sets_limpio.csv', sep=',')    # Carga de Datos
basket_sets=basket_sets.iloc[:,1:]                              # Descarto columna innecesaria


#%% ENTRENAMIENTO REGLAS DE ASOCIACION

# Calculo la frecuencia (soporte) de cada ítem por separado y en conjunto con los otros, dado un soporte mínimo deseado
frequent_itemsets = apriori(basket_sets, min_support=0.07, use_colnames=True)

# Una vez creada la matriz de ítems frecuentes, puedo crear las reglas de asociación
# también puedo filtar para un mínimo deseado, en este caso, métrica lift mínimo 2
rules = association_rules(frequent_itemsets, metric="lift", min_threshold=2)


#%% RESULTADOS

# Ordeno por lift de manera descendente
rules = rules.sort_values(by='lift', ascending=False)

# Extraer un top 50
TOP50 = rules.head(50)
TOP50.to_excel('REGLAS_TOP50.xlsx')


