# -*- coding: utf-8 -*-
"""
Created on Thu May 26 18:33:49 2022

@author: Andriu
"""

#%% IMPORTAR LIBRERIAS

import pandas as pd
import numpy as np

from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

#%% CARGA DE DATOS Y ESTANDARIZACION

Data = pd.read_excel('base_clientes_banco.xlsx', sheet_name='procesado')

# Estandarizacion del Dataset
Scaler = StandardScaler()               # Crea un escalador
DataNorm = Scaler.fit_transform(Data)   # Aqui escalo los datos

# Se puede observar que la edad original posee promedios en su respectiva escala
edades_original = Data.iloc[:,0]
np.mean(edades_original)
np.std(edades_original)

# La edad normalizada posee promedio = 0 y desviación = 1
edades_normal = pd.DataFrame(DataNorm).iloc[:,0]
np.mean(edades_normal)
np.std(edades_normal)


#%% ALGORITMO DE CLUSTERING - 1 MODELO 5 CLUSTERS

# --------------------- ENTRENAMIENTO DE MODELO -------------------------------

Kmeans_M0 = KMeans(n_clusters=5)    # Creo modelo de KMeans

Kmeans_M0.fit(DataNorm)             # Aplica el kmeans a la data escalada

Clusters_M0 = Kmeans_M0.labels_     # Me muestra los grupos


# --------------------- ESTRUCTURACION Y REVISION BASICA ----------------------

Clusters_M0 = pd.DataFrame(Clusters_M0,columns=['etiqueta_cluster'])

Resultado = pd.concat([Clusters_M0, Data],axis=1)      # Pega la columnas con la tabla

Resultado.to_excel('resultado_clustering.xlsx')        # Exporto a Excel

# Genero tablas para interpretar clusters:
estads = Resultado.describe() 
estads_por_cluster = Resultado.groupby('etiqueta_cluster').mean()       # Promedios de Caracteristicas por Cluster
estads_por_cluster_n = Resultado.groupby('etiqueta_cluster').count()    # Cantidad de Individuos por Cluster

# --------------------- SILUETA DEL MODELO  -----------------------------------

# Calculo la silueta para el modelo entrenado
silueta_M0 = silhouette_score(DataNorm, Kmeans_M0.labels_, metric='euclidean')
print(silueta_M0)


#%% ALGORITMO DE CLUSTERING - 20 MODELOS K CLUSTERS

n_modelos = 20 # Defino la cantidad de clusteres maximos a probar
etiquetas = [] # Creo una lista para guardar los resultados tras cada iteracion

for i in range(2,n_modelos+1):
    Kmeans_M0 = KMeans(n_clusters=i)    # Creo modelo de KMeans  
    Kmeans_M0.fit(DataNorm)             # Aplica el kmeans a la data escalada
    Clusters_M0 = Kmeans_M0.labels_     # Obtiene las etiquetas de cluster
    
    silueta = silhouette_score(DataNorm, Kmeans_M0.labels_, metric='euclidean')
    
    etiquetas.append([i,Clusters_M0,silueta]) # Almaceno los resultados
    
    print("Cluster: "+str(i))
    print("Silueta: "+str(silueta))
    
Cluster_Optimos = etiquetas[17][1]  # Selecciono las etiquetas del modelo optimo

Cluster_Optimos = pd.DataFrame(Cluster_Optimos,
                                columns=['etiqueta_cluster'])   # Doy formato DataFrame

Resultado_Optimo = pd.concat([Cluster_Optimos, Data], axis=1)   # Pega la columnas con la tabla

Resultado_Optimo.to_excel('resultado_optimo_clustering.xlsx')   # Exporto a Excel


# Genero tablas para interpretar clusters:
estads = Resultado_Optimo.describe() 
estads_por_cluster = Resultado_Optimo.groupby('etiqueta_cluster').mean()       # Promedios de Caracteristicas por Cluster
estads_por_cluster_n = Resultado_Optimo.groupby('etiqueta_cluster').count()    # Cantidad de Individuos por Cluster
