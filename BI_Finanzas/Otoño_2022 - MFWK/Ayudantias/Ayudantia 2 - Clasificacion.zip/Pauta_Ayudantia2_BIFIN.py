# -*- coding: utf-8 -*-
"""
Created on Thu Jun  2 05:58:17 2022

@author: Andriu
"""

#%% IMPORTAR LIBRERIAS
import numpy as np
import pandas as pd

from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.linear_model import SGDClassifier
from sklearn.metrics import f1_score
from sklearn.metrics import classification_report

#%% CARGAR DATOS
fuga_data = pd.read_excel("fuga_bancaria.xlsx")
clientes_data = pd.read_excel("cartera_clientes.xlsx")

seed = 14

#%% DEFINICION DE FUNCIONES 

def PREPROCESS_FUGA(DATA, TRAINING):
    #Definir indice y separar data
    indID = DATA.columns[0] 
    DATA.set_index(indID,drop=True,inplace=True)
    if (TRAINING==True):
        xdata = DATA.iloc[:,:len(DATA.columns)-1]
    else:
        xdata = DATA.iloc[:,:len(DATA.columns)]
    ydata = DATA.iloc[:,-1]
    
    #Aplicar MAPPINGS
    xdata["ZonaGeografica"] = xdata["ZonaGeografica"].map(zona_map)
    xdata["Genero"] = xdata["Genero"].map(genero_map)
    ydata = ydata.map(fuga_map) 
    
    if (TRAINING==True):
        return ydata, xdata
    else:
        return xdata


#%% PREPROCESO DE DATOS

#Generar MAPPINGS
zona_map = {"Sur":0, "Centro":50, "Norte":100}
genero_map = {"Mujer":0,"Hombre":1}
fuga_map = {"No":0, "Si":1}


#Aplico funcion de preproceso para ENTRENAR
Y, X = PREPROCESS_FUGA(fuga_data, True)


#%% TRAINING-TESTING SPLIT

# REALIZAR LA SEPARACION
Xtrain, Xtest, Ytrain, Ytest = train_test_split(X, Y, test_size=0.1, random_state=seed)

# ESCALAR TRAINING A ZSCORE

#Escalar X_train a Zscore
scaler = StandardScaler()
Xstrain = scaler.fit_transform(Xtrain)
    
#Dar Formato DataFrame
Xstrain = pd.DataFrame(Xstrain)
Xstrain.columns = Xtrain.columns
Xstrain.index = Xtrain.index


#%% ENTRENAMIENTO REGRESION LOGISTICA

#CONFIGURACION DE MODELO
LOG = LogisticRegression(penalty="none",fit_intercept=True, random_state=seed,
                         max_iter=1000,verbose=0)

#ENTRENAMIENTO DE MODELO
LOG.fit(Xstrain,Ytrain)

#APLICACION DEL MODELO
Yp_train = LOG.predict(Xtrain)
Yp_test = LOG.predict(Xtest)

#METRICA DE RENDIMIENTO
F_LOG_train= np.round(f1_score(Ytrain, Yp_train),10)
F_LOG_test = np.round(f1_score(Ytest, Yp_test),10)

#JUNTAR EN DATAFRAME
FSCORE = [F_LOG_train,F_LOG_test]
FSCORE_LOG = pd.DataFrame(FSCORE,columns=["LOG"],index=["Train","Test"])

print("Modelo Regresión Logistica")
print(classification_report(Ytest, Yp_test))

#%% ENTRENAMIENTO GRADIENTE DESCENDIENTE ESTOCASTICO

#CONFIGURACION DE MODELO
SGD = SGDClassifier(loss="hinge",penalty="none",alpha=0.001,fit_intercept=True, 
                    max_iter=1000,random_state=seed,verbose=0)

#ENTRENAMIENTO DE MODELO
SGD.fit(Xstrain,Ytrain)

#APLICACION DE MODELO
Yp_train = SGD.predict(Xtrain)
Yp_test = SGD.predict(Xtest)

#METRICA DE RENDIMIENTO
F_SGD_train= np.round(f1_score(Ytrain, Yp_train),10)
F_SGD_test = np.round(f1_score(Ytest, Yp_test),10)

#JUNTAR EN DATAFRAME
FSCORE = [F_SGD_train,F_SGD_test]
FSCORE_SGD = pd.DataFrame(FSCORE,columns=["SGD"],index=["Train","Test"])

print("Modelo Gradiente Descendiente Estocastico")
print(classification_report(Ytest, Yp_test))

#%% COMPARACION ENTRE MODELOS

FSCORE = pd.concat([FSCORE_LOG,FSCORE_SGD], axis=1)
FSCORE

#%% ENTRENAMIENTO MODELOS 2 al 5

print(clientes_data)

# PREPARAR DATOS
clientes_x = PREPROCESS_FUGA(clientes_data, False)

# APLICACION DE MODELO
clientes_yp = SGD.predict(clientes_x)

# ETIQUETACIÓN DE CLASE
clientes = clientes_x
clientes["FUGA (Yp)"] = clientes_yp

# EXPORTAR RESULTADO A EXCEL
clientes.to_excel("Clientes_AnalisisFuga.xlsx")















