# -*- coding: utf-8 -*-
"""
Created on Tue Aug 30 20:10:17 2022

@author: Andriu
"""

import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler


#%% LOAD DATA

df = pd.read_excel('Stock_Market_Data.xlsx')
df.set_index('Date',drop=True,inplace=True)

l = list(df.columns)[0:-2]


closes = []
for i in range(1,len(l),6):
    closes.append(i)

volumes = []
for i in range(5,len(l),6):
    volumes.append(i)
    
extras = [-2,-1]

features = closes + volumes + extras


df = df.iloc[:,features]

#%% 

missing = df.isnull().sum().sort_values(ascending=False)
missing = missing[missing >= 50]
missing = list(missing.index)

df.drop(missing,axis=1,inplace=True)

df.ffill(axis=0, inplace=True)


#%% 

Retornos = np.log(df.iloc[:,[0,1,2,3,4,5,6,7,-1]]/df.iloc[:,[0,1,2,3,4,5,6,7,-1]].shift(1))

list_retornos = [x+"_r" for x in list(Retornos.columns)]
Retornos.columns = list_retornos

Retornos = pd.concat([Retornos,df.iloc[:,8:-1]],axis=1)

Rezagos1 = Retornos.shift(1)
Rezagos2 = Retornos.shift(2)

list_rezagos1 = [x+"_lag1" for x in list(Retornos.columns)]
list_rezagos2 = [x+"_lag2" for x in list(Retornos.columns)]

Rezagos1.columns = list_rezagos1
Rezagos2.columns = list_rezagos2

Rezagos = pd.concat([Rezagos1,Rezagos2],axis=1)

Data_DF = pd.concat([Retornos['NFLX.OQ_CLOSE_r'].to_frame(),Rezagos],axis=1)
Data_DF.dropna(axis=0,inplace=True)


#%% 

CORR_MATRIX = Data_DF.corr()
CORR = np.abs(CORR_MATRIX.iloc[0,1:])
CORR.sort_values(ascending=False, inplace=True)

Data_DF = pd.concat([Data_DF.loc[:,'NFLX.OQ_CLOSE_r'],Data_DF.loc[:,list(CORR.head(20).index)]],axis=1)

zscaler = StandardScaler()

Data_DF_z = zscaler.fit_transform(Data_DF)
Data_DF_z = pd.DataFrame(Data_DF_z)
Data_DF_z.index = Data_DF.index
Data_DF_z.columns = Data_DF.columns

Y_DF = Data_DF_z.iloc[:,0].to_frame()
X_DF = Data_DF_z.iloc[:,1:]


#%% 

LinReg = LinearRegression()
LinReg.fit(X_DF,Y_DF)
COEFS = pd.DataFrame(LinReg.coef_.T,columns=['Coeficientes'])
COEFS.index = X_DF.columns
COEFS['ABS'] = np.abs(COEFS)
COEFS.sort_values(by="ABS",ascending=False,inplace=True)


COEFS.head(7)
