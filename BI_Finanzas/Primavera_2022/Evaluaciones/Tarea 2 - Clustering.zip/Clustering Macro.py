# -*- coding: utf-8 -*-
"""
Created on Mon Sep  5 16:34:36 2022

@author: Andriu
"""

#%% IMPORT PACKAGES

import pandas as pd

#%% LOAD DATA

df = pd.read_excel('data_economic_stage.xlsx')
df = df.iloc[:,1:]
df.set_index('Dates',drop=True,inplace=True)


