# -*- coding: utf-8 -*-
"""
Created on Mon Nov 14 15:26:18 2022

@author: Andriu
"""

#%% IMPORTAR LIBRERIAS

import numpy as np
import pandas as pd

#%% CLUSTERING MACROECONOMICO - 1.1

# 1.1.1 

tab = pd.read_excel("Material/data_economic_stage.xlsx",sheet_name="variables")
print(tab)

#%% CLUSTERING MACROECONOMICO - 1.2

# 1.2.1

df = pd.read_excel("Material/data_economic_stage.xlsx")
df.set_index('Dates',inplace=True,drop=True)

# 1.2.2 

from sklearn.preprocessing import StandardScaler

zscaler = StandardScaler()
dfz = zscaler.fit_transform(df)
dfz = pd.DataFrame(dfz,index=df.index,columns=df.columns)

# Manualmente

means = df.mean()
desv = df.std()

print(means)
print(desv)

dfzm = (df-means)/desv

zmeans = np.round(dfzm.mean())
zdesv = dfzm.std()

print(zmeans)
print(zdesv)

#%% CLUSTERING MACROECONOMICO - 1.3

from sklearn.cluster import KMeans

# 1.3.1 

km = KMeans(n_clusters=3,max_iter=2000,random_state=14)
clust = km.fit_predict(dfz)

df['LABELS'] = clust
df.to_excel('OUTPUT/CLUST_1.xlsx')

#%% CLUSTERING MACROECONOMICO - 1.4

# 1.4.1
ncent = df.groupby('LABELS').count()
ncent = ncent.iloc[:,0]

cent = df.groupby('LABELS').mean()
cent['N'] = ncent

cent = cent.T

cent.to_excel('OUTPUT/CENT_1.xlsx')


# 1.4.4

import plotly.express as px
from plotly.offline import plot as offplot

dfp = df['LABELS'].to_frame()
dfp['DATE'] = dfp.index
dfp['CLUSTER'] = dfp['LABELS'].map({0:'Auge',1:'Recesion',2:'Transicion'})
dfp['CLASS'] = dfp['LABELS'].map({0:1,1:-1,2:0})

fig = px.scatter(dfp,x='DATE',y='CLASS',color='CLUSTER',color_discrete_sequence=['green','grey','red'],title='CLUSTERING MACROECONOMICO')
fig.update_layout(showlegend=False,legend_font_size=20,plot_bgcolor='white',title_xanchor='center',title_x=0.5,title_font_size=20,width=1080,height=540)
fig.update_xaxes(dividercolor="black",dividerwidth=5,gridcolor='lightgrey',griddash='dash',linecolor='black',nticks=45)
fig.update_yaxes(linecolor='black')
offplot(fig)
