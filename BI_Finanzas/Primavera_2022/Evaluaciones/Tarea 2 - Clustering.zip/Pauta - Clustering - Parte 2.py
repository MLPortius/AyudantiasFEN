# -*- coding: utf-8 -*-
"""
Created on Mon Nov 14 17:54:47 2022

@author: Andriu
"""

#%% IMPORTAR LIBRERIAS

import numpy as np
import pandas as pd

#%% CLUSTERING CONTABLE-FINANCIERO 2.2

# 2.2.1

df = pd.read_excel("Material/data_fundamentals.xlsx")
tickers = list(df['Ticker Symbol'].unique())

df.set_index('Ticker Symbol',drop=True,inplace=True)

# SEPARO LOS DATAFRAMES SEGUN SU TICKER
tick_dict = {}
for t in tickers:
    tick_dict[t] = df.loc[t,:]

# FILTRO LA ULTIMA FECHA DE CADA TICKER
for t in tickers:
    tick_dict[t] = tick_dict[t].iloc[-1,:]
    
# JUNTO LOS DATAFRAMES FILTRADOS EN UNO SOLO

dff = tick_dict[tickers[0]].to_frame()
for t in tickers[1:]:
    dff = pd.concat([dff,tick_dict[t]],axis=1)

dff = dff.T
dff.drop('Period Ending',axis=1,inplace=True)
dff = dff.astype(float)

list(dff.columns)

# 2.2.2

dff1 = dff.loc[:,["Gross Margin","Profit Margin","Operating Margin","Quick Ratio"]]
dff1 = dff1/100

# 2.2.3


dff1['Gross Profit'] = dff['Gross Profit']
dff1['Net Sales'] = dff1['Gross Profit']/dff1['Gross Margin']
# Para las Net Sales conviene llenar los missing values con un promedio

dff1['EBITDA'] = dff['Earnings Before Interest and Tax'] + dff['Depreciation']

dff1['DEBT'] = dff['Short-Term Debt / Current Portion of Long-Term Debt']+dff['Long-Term Debt']

# 2.2.4

dff2 = dff1.loc[:,['Gross Margin','Profit Margin','Operating Margin','Quick Ratio']]

dff2['ROE'] = dff['Net Income']/dff['Total Equity']
dff2['EBITDA Margin'] = dff1['EBITDA']/dff1['Net Sales'] # Missing Values
dff2['EBITDA Coverage'] = dff['Interest Expense']/dff1['EBITDA']
dff2['Cash Ratio'] = dff['Cash and Cash Equivalents']/dff['Total Current Liabilities'] # Inf Values and Missing Values
dff2['Leverage'] = dff1['DEBT']/dff['Total Equity']
dff2['Current Ratio'] = dff['Total Current Assets']/dff['Total Current Liabilities'] # Missing Values
dff2['Assets/Liabilities'] = dff['Total Assets']/dff['Total Liabilities']
dff2['R+D/GrossMargin'] = dff['Research and Development']/dff1['Gross Margin'] # Missing Values
dff2['Debt Term'] = dff['Short-Term Debt / Current Portion of Long-Term Debt']/dff['Long-Term Debt'] # Missing Values y Inf Values
dff2['EBITDA/DEBT'] = dff1['EBITDA']/dff1['DEBT'] # Inf Values
dff2['ROA'] = dff['Net Income']/dff['Total Assets']
dff2['Intangible/Assets'] = dff['Intangible Assets']/dff['Total Assets']
dff2['Interest Rate'] = dff['Interest Expense']/dff1['DEBT'] # Inf Values


#%% 2.2.5

cols = ['RENTABILIDAD','LIQUIDEZ','ENDEUDAMIENTO','SOLVENCIA','OTROS']
ratios = list(dff2.columns)
classif = [[1,0,0,0,0],[1,0,0,0,0],[1,1,0,0,0],[0,1,0,0,0],[1,0,0,0,0],
           [1,1,0,0,0],[0,1,0,1,0],[0,1,0,0,0],[0,0,1,0,0],[0,1,0,0,0],
           [0,0,1,1,0],[0,0,0,0,1],[0,0,1,0,0],[0,1,1,1,0],[1,0,0,0,0],
           [0,0,0,0,1],[0,0,1,0,0]]

tab = pd.DataFrame(classif,columns = cols,index = ratios)
for c in list(tab.columns):
    tab[c] = tab[c].map({0:'no',1:'si'})
    

#%% 2.2.7 CORREGIR DATA

dft = dff2.copy()

for c in list(dft.columns):
    dft[c][dft[c] == np.inf] = np.nan

mvcount = dft.isna().sum(axis=1)
mvcount.sort_values(ascending=False,inplace=True)
mvcount = mvcount/len(dff2.columns)

n_filas_con_mv = len(mvcount[mvcount != 0].index)


# CORREGIR RATIOS
# ------------------------- QUICK RATIO -------------------------------------
null_ind = list(dff2[dff2['Quick Ratio'].isna()].index)

dft = pd.concat([dff['Total Current Assets'],dff['Total Current Liabilities'],
                 dff['Inventory'],dff['Deferred Asset Charges'],],axis=1)
dft = dft.loc[null_ind,:]

# Debido a que en este caso es complicado calcular el valor con otro método, 
# utilizaré el promedio

mean_rate = dff1.loc[:,'Quick Ratio'].mean()
dff2.loc[null_ind,'Quick Ratio'] = dff2.loc[null_ind,'Quick Ratio'].fillna(mean_rate)
dff2['Quick Ratio'] = dff2['Quick Ratio'].astype(float)


# ------------------------- EBITDA MARGIN ------------------------------------
# Estimo el margen de EBITDA por multiplo promedio
null_ind = list(dff1[dff1['Net Sales'].isna()].index)

dft = pd.concat([dff1['EBITDA'],dff1['Net Sales'],dff2['EBITDA Margin']],axis=1)
dft.loc[null_ind,:]
# mv por mv en Net Sales
dft = pd.concat([dff1['Gross Profit'],dff1['Gross Margin'],dff1['Net Sales']],axis=1)
dft.loc[null_ind,:]
# mv por 0 en Gross Profit y Gross Margin 

#Estimare el ratio como Multiplo
dft = pd.concat([dff1['EBITDA'],dff2['EBITDA Margin']],axis=1)
dft.dropna(axis=0,inplace=True)
dft['rate'] = dft['EBITDA Margin']/dft['EBITDA']
mean_rate = dft['rate'].mean()

# Reemplazo
dff2.loc[null_ind,'EBITDA Margin'] = dff1.loc[null_ind,'EBITDA']*mean_rate


# ------------------------- CASH RATIO -------------------------------------
inf_ind = list(dff2[dff2['Cash Ratio'] == np.inf].index)
null_ind = list(dff2[dff2['Cash Ratio'].isna()].index)


dft = pd.concat([dff2['Cash Ratio'],dff['Cash and Cash Equivalents'],dff['Total Current Liabilities']],axis=1)

# Causa de INF es Total Current Liabilities = 0
# Causa de MV es Total Current Liabilities = nan

# Calcularemos Total Current Liabilities por Multiplos
dft = pd.concat([dff['Total Current Liabilities'],dff['Total Liabilities']],axis=1)
dft = dft[dft['Total Current Liabilities'] != 0]
dft['rate'] = dft['Total Current Liabilities']/dft['Total Liabilities']

mean_rate = dft['rate'].mean()

# Reemplazo
dff.loc[inf_ind,'Total Current Liabilities'] = dff.loc[inf_ind,'Total Liabilities']*mean_rate
# dff.loc[null_ind,'Total Current Liabilities'] = dft.loc[null_ind,'Total Liabilities']*mean_rate

# Vuelvo a calcular el Ratio
dff2['Cash Ratio'] = dff['Cash and Cash Equivalents']/dff['Total Current Liabilities'] 


# ------------------------- CURRENT RATIO -------------------------------------
null_ind = list(dff2[dff2['Current Ratio'].isna()].index)

dft = pd.concat([dff2['Current Ratio'],dff['Total Current Assets'],dff['Total Current Liabilities']],axis=1)
dft.loc[null_ind,:]
# La causa de los valores nulos es Total Current Assets

# Estimamos la proporcion de Total Current Assets
dft = pd.concat([dff['Total Current Assets'],dff['Total Assets']],axis=1)
dft = dft[dft['Total Current Assets']!=0]
dft['rate'] = dft['Total Current Assets']/dft['Total Assets']

mean_rate = dft['rate'].mean()

# Reemplazamos
dff.loc[null_ind,'Total Current Assets'] = dff.loc[null_ind,'Total Assets'] * mean_rate

# Vuelvo a calcular el Ratio
dff2['Current Ratio'] = dff['Total Current Assets']/dff['Total Current Liabilities']

# ------------------------- R+D RATIO -------------------------------------
dff2['R+D/GrossMargin'] = dff['Research and Development']/dff1['Gross Margin'] # Missing Values

dft = pd.concat([dff2['R+D/GrossMargin'],dff['Research and Development'],dff1['Gross Margin']],axis=1)

#Vemos que el Ratio no queda muy bien construido debido a las escalas, valores nulos, valores cero, entro otros.
#Podemos descartarlo o reemplazarlo por otra variable

#En este caso, lo descartaremos

dff2.drop('R+D/GrossMargin',axis=1,inplace=True)

# ------------------------- DEBT TERM RATIO  ----------------------------------

dff2['Debt Term'] = dff['Short-Term Debt / Current Portion of Long-Term Debt']/dff['Long-Term Debt'] # Missing Values y Inf Values

dft = pd.concat([dff2['Debt Term'],dff['Short-Term Debt / Current Portion of Long-Term Debt'],dff['Long-Term Debt']],axis=1)
null_ind = list(dff2[dff2['Debt Term'].isna()].index)
inf_ind = list(dff2[dff2['Debt Term'] == np.inf].index)

dft1 = dft.loc[inf_ind,:]

# Inf Values
dft3 = dft.copy()

dft3 = dft3[dft['Debt Term'] != np.inf]
dft3.dropna(axis=0,inplace=True)
dft3['SRrate'] = dft3['Debt Term']/dft3['Short-Term Debt / Current Portion of Long-Term Debt']
dft3.dropna(axis=0,inplace=True)

mean_rate = dft3['SRrate'].mean()

dff2.loc[inf_ind,'Debt Term'] = dff.loc[inf_ind,'Short-Term Debt / Current Portion of Long-Term Debt']*mean_rate

# Missing Values
dft2 = dft.loc[null_ind,:]
dff2['Debt Term'] = dff2['Debt Term'].fillna(1)

# ------------------------- EBITDA/DEBT RATIO  --------------------------------
dff2['EBITDA/DEBT'] = dff1['EBITDA']/dff1['DEBT'] # Inf Values

dft = pd.concat([dff2['EBITDA/DEBT'],dff1['EBITDA'],dff1['DEBT']],axis=1)
inf_ind = list(dft[dft['EBITDA/DEBT']==np.inf].index)

# Causa de Missing Values es DEBT igual a cero
dft1 = dft[dft['EBITDA/DEBT'] != np.inf]
dft1 = dft1.copy()
dft1['rate'] = dft1.loc[:,'EBITDA/DEBT']/dft1.loc[:,'EBITDA']

mean_rate = dft1['rate'].mean()

dff2.loc[inf_ind,'EBITDA/DEBT'] = dff1.loc[inf_ind,'EBITDA']*mean_rate

# ------------------------- INTEREST RATE RATIO  ------------------------------
dff2['Interest Rate'] = dff['Interest Expense']/dff1['DEBT'] # Inf Values

dft = pd.concat([dff2['Interest Rate'],dff['Interest Expense'],dff1['DEBT']],axis=1)

inf_ind = list(dft[dft['Interest Rate']==np.inf].index)

dft.loc[inf_ind,:]
# Causa de Inf Values es debt = 0

dft1 = dft[dft != np.inf]
dft1.dropna(axis=0,inplace=True)
dft1 = dft1.copy()
dft1['rate'] = dft1['Interest Rate']/dft1['Interest Expense']

mean_rate = dft1['rate'].mean()

dff2.loc[inf_ind,'Interest Rate'] = dff.loc[inf_ind,'Interest Expense']*mean_rate


null_ind = list(dft[dft['Interest Rate'].isna()].index)

dft.loc[null_ind,:]
# Causa de Missing Value Interest Expense y DEBT = 0

dff2['Interest Rate'].fillna(0,inplace=True)


del(dft,dft1,dft2,dft3,inf_ind,mean_rate,null_ind)


#%% 2.2.7 ESTANDARIZACION

from sklearn.preprocessing import StandardScaler

zscaler = StandardScaler()
dfz = zscaler.fit_transform(dff2)

dfz = pd.DataFrame(dfz,index=dff2.index,columns=dff2.columns)

#%% 2.3.1 ALGORITMO CLUSTERING

from sklearn.cluster import Birch


#%% 2.3.2 

np.random.seed(14)
from sklearn.metrics import silhouette_score

# Diseño la grilla
t_grid = [0.1,0.3,0.5,0.7,0.9,1,1.25,1.5,1.75,2,2.5,3,4,5,7,10]
b_grid = [2,5,10,15,20,25,30,40,50,60,80,100,150,200]
k_grid = [2,3,4,5,6,7,8,9,10]

grid = []
for t in t_grid:
    for b in b_grid:
        for k in k_grid:
            grid.append([t,b,k])
            

# Implemento la grilla

results = []
for g in grid:
    print(g,'...')
    model = Birch(threshold=g[0],branching_factor=g[1],n_clusters=g[2])
    model.fit(dfz)
    
    score = -10
    
    labels = model.predict(dfz)
    labels = pd.DataFrame(labels,index=dfz.index,columns=['Cluster'])
    labels = labels['Cluster']
    
    nclust = len(labels.unique())
    
    if nclust > 1:
        score = silhouette_score(dfz, labels, random_state=14)

    r = pd.DataFrame([g[0],g[1],g[2],score])
    r.index = ['thr','bfactor','kcluster','score']

    results.append({'results':r,'yp':labels})

#%% 2.3.3

import plotly.express as px
from plotly.offline import plot as offplot

dfr = results[0]['results']
for cfg in results[1:]:
    dfr = pd.concat([dfr,cfg['results']],axis=1)

dfr = dfr.T

dfr.reset_index(inplace=True,drop=True)
dfr.sort_values('score',ascending=False,inplace=True)
dfr = dfr[dfr['score'] != -10]

fig = px.scatter_3d(dfr,x='thr',y='bfactor',z='score',color='kcluster')
offplot(fig)

fig = px.scatter(dfr,x='kcluster',y='score')
offplot(fig)


# La configuración que considero más deseable para este caso es:
opt = dfr.loc[1262,:]
opt_results = results[1262]    

labels = opt_results['yp']

dff2['CLUSTER'] = labels
dff2['CLUSTER'].value_counts()

# Exporto los resultados
dff2.to_excel('OUTPUT/CLUST_2.xlsx')

#%% 2.4.1

nclust = dff2['CLUSTER'].value_counts()
cent = dff2.groupby('CLUSTER').mean()

cent = pd.merge(nclust,cent,left_index=True,right_index=True)
cent = cent.T

cent.to_excel('OUTPUT/CENT_2.xlsx')
