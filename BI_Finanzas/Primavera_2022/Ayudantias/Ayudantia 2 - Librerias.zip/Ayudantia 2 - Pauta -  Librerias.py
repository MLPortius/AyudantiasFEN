# -*- coding: utf-8 -*-
"""
Created on Thu Aug 11 21:28:28 2022

@author: Andriu
"""


#%% BUCLES Y LISTAS - EJERCICIO 1

# CREAR UNA FUNCION QUE GENERE UNA LISTA CON LOS PRIMEROS N NUMEROS IMPARES

def EJERCICIO_1_1_1(n):
    
    lista = []
    
    for i in range(n):
        num = 2*i + 1
        lista.append(num)
    
    return lista


lista_1_1_1 = EJERCICIO_1_1_1(500)


#%% BUCLES Y LISTAS - EJERCICIO 2

# CREAR UNA LISTA DE 20 LISTAS, DONDE CADA UNA VAYA DEL [0-9],[10-19],[20-29]... Y EXTRAER EL CUARTO NUMERO DE LA OCTAVA LISTA

lista_1_2 = []

for i in range(20):
    
    lista_i = []

    for k in range(10):
        num = k + (10*i)
        lista_i.append(num)
        
    lista_1_2.append(lista_i)
    
    del lista_i


lista_1_2[7][3]


#%% BUCLES Y LISTAS - EJERCICIO 3

# CREAR UNA LISTA QUE VAYA DESDE [0-10],[20-30],[40-50]
# CREAR UNA FUNCION QUE GENERE UNA LISTA ANEXA, DONDE INDIQUE SI EL NUMERO RESPECTIVO EN LA PRIMERA LISTA ES DIVISIBLE POR 3 O NO.


lista_1_3 = []

for i in range(3):
    for k in range(11):
        num = k + (10*(2*i))
        lista_1_3.append(num)


# LISTA ANEXA

def EJERCICIO_1_3_2(lista):
    
    anexa = []
    
    for num in lista:
        if (num%3 == 0):
            anexa.append('divsible')
        else:
            anexa.append('no divisible')
            
    return anexa

lista_1_3_anexa = EJERCICIO_1_3_2(lista_1_3)



#%% MATRICES CON NUMPY

import numpy as np

# CREAR UNA MATRIZ

matriz = np.array(([1,2,3],[4,5,6],[7,8,9]))
matriz

# TRANSPONER UNA MATRIZ

matriz.T

# EXTRAER ELEMENTOS DE MATRIZ [FILAS][COLUMNAS]

matriz[0]           # Primera fila

matriz[:][0]        # Primera Columna

matriz[0][0]        # Elemento 1,1


# SUMARLE A TODOS LOS ELEMENTOS DE LA MATRIZ UN 1O
matriz + 10

# MULTIPLICAR TODOS LOS ELEMENTOS DE LA MATRIZ POR 10
matriz * 10

# SUMA Y MULTIPLICACION DIRECTA DE MATRICES
matriz2 = np.array(([10,10,10],[20,20,20],[30,30,30]))

matriz
matriz2

matriz + matriz2
matriz * matriz2

# MULTIPLICACION MATRICIAL
matriz.dot(matriz2)

matriz3 = np.array(([1],[2],[3]))
matriz3

matriz.dot(matriz3)

# OTROS OPERADORES DE NUMPY
matriz.flatten()    # TRANSFORMAR LA MATRIZ EN UN SOLO VECTOR
matriz.diagonal()   # OBTENER EL VECTOR DIAGONAL DE LA MATRIZ
matriz.shape        # OBTENER DIMENSIONES DE LA MATRIZ (FILAS, COLUMNAS)

# ALGEBRA LINEAL CON NUMPY
np.linalg.det(matriz)   # OBTENER EL DETERMINANTE DE UNA MATRIZ
np.linalg.inv(matriz)   # OBTENER LA MATRIZ INVERSA

# MATEMATICAS CON NUMPY
np.abs(-5)                              # OBTENER VALOR ABSOLUTO
np.mean([4,6,10,20,1,2,4,6,5,3,1,6,9])  # OBTENER EL PROMEDIO DE UNA LISTA DE NUMEROS
np.sqrt(100)                            # OBTENER RAIZ CUADRADA
np.log(10)                              # OBTENER LOGARITMO NATURAL DE 10
np.log10(100)                           # OBTENER LOGARITMO BASE10 DE 100


#%% DATAFRAME CON PANDAS

import pandas as pd

# CREAR UN DATAFRAME
lista = [[1,2,3,5,6],[4,5,6],[7,8,9,5]]
data = pd.DataFrame(lista)

# RENOMBRAR COLUMNAS
data.columns = ['Cifra1','Cifra2','Cifra3','Cifra4','Cifra5']

# RENOMBRAR INDICE
data.index = ['Vector1','Vector2','Vector3']

# EXTRAER ELEMENTO FILA 1 Y COLUMNA 3
data.iloc[0,2]                  # DESDE EL NUMERO DE POSICION
data.loc['Vector1','Cifra3']    # DESDE EL VALOR EN EL INDICE Y COLUMNA

# EXTRAER LA FILA 1 COMPLETA
fila1 = data.iloc[0,:]
fila1 = data.loc['Vector1',:]

# EXTRAER LA COLUMNA 2 COMPLETA
columna2 = data.iloc[:,1]
columna2 = data.loc[:,'Cifra2']

# EXTRAER AL PENULTIMO NUMERO DE LA FILA 1
data.iloc[0,-1]

# EXTRAER LAS DOS PRIMERAS FILAS
data.iloc[0:2,:]         # COMO RANGO O SLICE
data.iloc[[0,1],:]       # COMO SELECCION

# EXTRAER LOS DOS ULTIMAS COLUMNAS
data.iloc[:,-2:]

# INSERTAR UN 10 EN EL VECTOR 2 CIFRA 4
data.loc['Vector2','Cifra4'] = 10

# RELLENAR LOS MISSING VALUES CON UN CERO
data = data.fillna(0)

# GENERE UNA NUEVA CIFRA DONDE TODO SEA 1
data['Cifra6'] = 1

# GENERE UN NUEVO DATAFRAME DONDE CADA COLUMNA SEA EL PROMEDIO DE UNA CIFRA
data2 = data.mean(axis=0)
data2 = pd.DataFrame(data2)
data2 = data2.transpose()
data2.index = ['mean']

# GENERE UN NUEVO DATAFRAME DONDE CADA FILA SEA EL PROMEDIO DEL VECTOR
data3 = data.mean(axis=1)
data3 = pd.DataFrame(data3)
data3.columns = ['mean']

# CARGAR DATOS DESDE EXCEL 
data = pd.read_excel('NombreDelArchivo.xlsx')

# GUARDAR DATOS EN EXCEL
data.to_excel('NombreDelArchivoNuevo.xlsx') 


#%% GRAFICOS CON MATPLOTLIB

import matplotlib.pyplot as plt 

lista = [1,2,3,0,1,2,2,3,4,1,2,3,0]  


# LOS PARAMETROS DEL GRAFICO SE DEBEN CORRER AL MISMO TIEMPO, SE ACUMULARAN Y
# MOSTRARAN AL CORRER EL ULTIMO CODIGO SHOW()

plt.figure(0, figsize=(15,5))           # DEFINO UN NUMERO PARA LA FIGURA
plt.plot(lista,color='purple')          # DEFINO UN TIPO DE GRAFICO Y SUS DATOS
plt.xlabel('Indice del Vector')         # DEFINO UN NOMBRE DEL EJE X
plt.ylabel('Valor del Vector')          # DEFINO UN NOMBRE DEL EJE Y
plt.xticks(list(range(13)))             # DEFINO QUE NUMEROS SE MOSTRARAN EN EL EJE X
plt.yticks(list(range(5)))              # DEFINO QUE NUMEROS SE MOSTRARAN EN EL EJE Y
plt.grid(axis='both',linestyle='--')    # DEFINO LA GRILLA PARA EL GRAFICO
plt.title('GRAFICO DE EJEMPLO PYPLOT')  # DEFINO UN TITULO PARA EL GRAFICO
plt.axhline(y=np.mean(lista),color='k') # AGREGO UNA LINEA QUE MARCA EL PROMEDIO
plt.show()


#%% EJERCICIO FINAL

# CARGAR LOS PRECIOS DE LA ACCION AAPL DESDE EXCEL
PreciosAAPL = pd.read_excel('AAPL_StockData.xlsx')

# SELECCIONAR SOLAMENTE LA FECHA Y EL PRECIO DE CIERRE 
PreciosAAPL = PreciosAAPL.loc[:,['Date','CLOSE']]

# GENERAR UNA COLUMNA CON EL REZAGO DEL PRECIO (HINT: FUNCION .shift())
PreciosAAPL['Rez_CLOSE'] = PreciosAAPL.iloc[:,1].shift(1)

# DEFINIR LAS FECHAS COMO INDICE DE LAS FILAS (HINT: FUNCION .set_index())
PreciosAAPL.set_index('Date',drop=True,inplace=True)



# CALCULAR EN UN NUEVO DATAFRAME EL RETORNO DE LA ACCION (HINT: Rt = ln(R(t)/R(t-1))
RetornosAAPL = PreciosAAPL['CLOSE']/PreciosAAPL['Rez_CLOSE']
RetornosAAPL = np.log(RetornosAAPL)
RetornosAAPL = pd.DataFrame(RetornosAAPL)
RetornosAAPL.columns = ['RETURN']

# GENERAR DOS REZAGOS DEL RETORNO 
RetornosAAPL['R1_RETURN'] = RetornosAAPL['RETURN'].shift(1)
RetornosAAPL['R2_RETURN'] = RetornosAAPL['RETURN'].shift(2)

# ELIMINAR LAS FILAS CON VALORES NULOS (HINT: FUNCION .dropna())
RetornosAAPL.dropna(axis=0, inplace=True)



# GENERAR UN GRAFICO PARA LOS PRECIOS DE CIERRE
plt.figure(1, figsize=(10,5))
plt.plot(PreciosAAPL.loc[:,'CLOSE'])
plt.title('EVOLUCION DEL PRECIO - APPLE')
plt.grid(axis='x',linestyle='--')
plt.show()

# GENERAR UN GRAFICO PARA LOS RETORNOS DEL ACTIVO
plt.figure(2, figsize=(10,5))
plt.plot(RetornosAAPL.loc[:,'RETURN'],color='purple')
plt.title('EVOLUCION DEL RETORNO - APPLE')
plt.axhline(y=0,color='white',linestyle='--')
plt.show()



# EXPORTAR PRECIO DE CIERRE, RETORNOS Y REZAGOS DE RETORNOS A EXCEL (HINT= FUNCTION .concat())
Data = pd.concat([PreciosAAPL['CLOSE'],RetornosAAPL],axis=1)
Data.dropna(axis=0,inplace=True)
Data.to_excel('RetornosAAPL.xlsx')

