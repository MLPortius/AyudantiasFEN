# -*- coding: utf-8 -*-
"""
Created on Thu Nov  3 03:04:22 2022

@author: Andriu
"""

#%% IMPORTAR LIBRERIAS

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
# import plotly.express as px
# from plotly.offline import plot
# import plotly.graph_objects as go
# import matplotlib.pyplot as plt

#%% CONFIGURAR

in_file = 'BD_Mundo.xlsx'
out_file = 'BD_Ratios_Mundo.xlsx'

#%% GET COUNTRIES AND VARIABLES

PAIS = pd.read_excel(in_file,sheet_name='PAISES')
PAIS.set_index('ID',drop=True,inplace=True)
COUNTRY_CODES = list(PAIS.index)

VARS_DF = pd.read_excel(in_file,sheet_name='FUENTE')
VARS_DF.set_index('CODIGO',inplace=True,drop=True)
VARS = list(VARS_DF.index)

TYPES = VARS_DF.copy()
TYPES = TYPES.loc[:,['COLECCIÓN DE DATOS','TIPO']]

#%% DEFINE VARIABLE CLASS

class VARIABLE:
    
    def __init__(self, varcode, varDF, data_file, codes_list):
        
        self.clist = codes_list
        self.code = varcode
        self.name = varDF.loc[varcode,'COLECCIÓN DE DATOS']
        self.type = varDF.loc[varcode,'TIPO']
        
        df = pd.read_excel(data_file,sheet_name=varcode)
        df.set_index('ID',inplace=True,drop=True)
        df = df.loc[codes_list,:]
        
        self.data = df
        self.dat = pd.DataFrame()
        self.dcp = pd.DataFrame()
        self.dmp = pd.DataFrame()
        self.dlp = pd.DataFrame()        
        self.dhs = pd.DataFrame()
        
        self.conf = pd.DataFrame()
        self.plazos = dict()
        self.pmconf = pd.Series(dtype='object')
        self.cmconf = pd.Series(dtype='object')
        
        self.cpres = pd.DataFrame()
        self.mpres = pd.DataFrame()
        self.lpres = pd.DataFrame()
        self.hsres = pd.DataFrame()
        
        self.terms_dict = {}
        self.cleaned = 0
        self.output = pd.DataFrame()
        
        self.scale = 1
        self.outlier = 0
        
    def STUDY(self):
        
        df = self.data 
        
        means = df.mean(axis=1).mean(axis=0)
        mn_str = str(int(np.trunc(means)))
        mn_len = len(list(mn_str))
        self.outlier = -(10**mn_len)
        
        if mn_len >= 6:
            df = df/(10**6)
            self.data = df
            self.scale = (10**6)
            self.outlier = self.outlier/(10**6)
        
        hs = list(df.columns)
        lp = hs[-30:]
        mp = hs[-12:]
        cp = hs[-4:]
        at = hs[-1]
        
        pdict = {}
        pdict['hs'] = hs
        pdict['lp'] = lp
        pdict['mp'] = mp
        pdict['cp'] = cp
        pdict['at'] = at
        
        self.plazos = pdict
        
        dfat = df.loc[:,at].to_frame()
        dfcp = df.loc[:,cp]
        dfmp = df.loc[:,mp]
        dflp = df.loc[:,lp]

        self.dat = dfat
        self.dcp = dfcp
        self.dmp = dfmp
        self.dlp = dflp
        self.dhs = df
        
        acc_at = 1 - dfat.isna().sum(axis=1)/len(dfat.columns)
        acc_cp = 1 - dfcp.isna().sum(axis=1)/len(dfcp.columns)
        acc_mp = 1 - dfmp.isna().sum(axis=1)/len(dfmp.columns)
        acc_lp = 1 - dflp.isna().sum(axis=1)/len(dflp.columns)
        acc_hs = 1 - df.isna().sum(axis=1)/len(df.columns)
        
        accDF = pd.DataFrame(index=df.index)
        accDF['conf_at'] = acc_at
        accDF['conf_cp'] = acc_cp
        accDF['conf_mp'] = acc_mp
        accDF['conf_lp'] = acc_lp
        accDF['conf_hs'] = acc_hs
        
        self.conf = accDF
        
        self.pmconf = accDF.mean(axis=0)
        self.cmconf = accDF.mean(axis=1)

    def CLEAN_MSV(self):
        
        dat = self.dat
        dcp = self.dcp
        dmp = self.dmp
        dlp = self.dlp
        dhs = self.dhs
        
        dhs.ffill(axis=1,inplace=True)
        dhs.bfill(axis=1,inplace=True)
        dhs.fillna(self.outlier,inplace=True)
        
        dlp.ffill(axis=1,inplace=True)
        dlp.bfill(axis=1,inplace=True)
        dlp.fillna(self.outlier,inplace=True)
        
        dmp.ffill(axis=1,inplace=True)
        dmp.bfill(axis=1,inplace=True)
        dmp.fillna(self.outlier,inplace=True)
        
        dcp.ffill(axis=1,inplace=True)
        dcp.bfill(axis=1,inplace=True)
        dcp.fillna(self.outlier,inplace=True)
        
        dat = dhs.iloc[:,-1].to_frame()
        
        self.dat = dat
        self.dcp = dcp
        self.dmp = dmp
        self.dlp = dlp
        self.dhs = dhs
        
        
    def GET_CP(self,verbose=False):
        
        data = self.dcp
        
        # DESCRIPTIVE
        
        mean = data.mean(axis=1)
        std = data.std(axis=1)
        
        # LINEAR REGRES
        
        # normal = data.copy()

        # for ind in list(data.index):
        #     serie = data.loc[ind,:]
        #     first = data.loc[ind,list(data.columns)[0]]
        #     norm = serie/first
        #     normal.loc[ind,:] = norm

        a_vector = []
        b_vector = []
        
        for ind in list(data.index):
            
            if verbose:
                print('Linreg...',ind)
            
            vector = np.asarray(data.loc[ind,:])
            
            x = np.arange(len(vector))
            y = vector

            linreg = LinearRegression()
            linreg.fit(x.reshape(-1,1), y) 

            b = linreg.coef_[0]
            a = linreg.intercept_
            
            a_vector.append(a)
            b_vector.append(b)
        
        cp = pd.concat([mean,std],axis=1)
        cp.columns = ['mean','std']
        cp['alpha'] = a_vector
        cp['beta'] = b_vector
        
        self.cpres = cp
        
    def GET_MP(self,verbose=False):
        
        data = self.dmp
        
        # DESCRIPTIVE
        
        mean = data.mean(axis=1)
        std = data.std(axis=1)
        
        # LINEAR REGRES
        
        # normal = data.copy()

        # for ind in list(data.index):
        #     serie = data.loc[ind,:]
        #     first = data.loc[ind,list(data.columns)[0]]
        #     norm = serie/first
        #     normal.loc[ind,:] = norm

        a_vector = []
        b_vector = []
        
        for ind in list(data.index):
            
            if verbose:
                print('Linreg...',ind)
            
            vector = np.asarray(data.loc[ind,:])
            
            x = np.arange(len(vector))
            y = vector

            linreg = LinearRegression()
            linreg.fit(x.reshape(-1,1), y) 

            b = linreg.coef_[0]
            a = linreg.intercept_
            
            a_vector.append(a)
            b_vector.append(b)
        
        mp = pd.concat([mean,std],axis=1)
        mp.columns = ['mean','std']
        mp['alpha'] = a_vector
        mp['beta'] = b_vector
        
        self.mpres = mp
        
    def GET_LP(self,verbose=False):
        
        data = self.dlp
        
        # DESCRIPTIVE
        
        mean = data.mean(axis=1)
        std = data.std(axis=1)
        
        # LINEAR REGRES
        
        # normal = data.copy()

        # for ind in list(data.index):
        #     serie = data.loc[ind,:]
        #     first = data.loc[ind,list(data.columns)[0]]
        #     norm = serie/first
        #     normal.loc[ind,:] = norm

        a_vector = []
        b_vector = []
        
        for ind in list(data.index):
            
            if verbose:
                print('Linreg...',ind)
            
            vector = np.asarray(data.loc[ind,:])
            
            x = np.arange(len(vector))
            y = vector

            linreg = LinearRegression()
            linreg.fit(x.reshape(-1,1), y) 

            b = linreg.coef_[0]
            a = linreg.intercept_
            
            a_vector.append(a)
            b_vector.append(b)
        
        lp = pd.concat([mean,std],axis=1)
        lp.columns = ['mean','std']
        lp['alpha'] = a_vector
        lp['beta'] = b_vector
        
        self.lpres = lp

    def GET_HS(self,verbose=False):
        
        data = self.dhs
        
        # DESCRIPTIVE
        
        mean = data.mean(axis=1)
        std = data.std(axis=1)
        
        # LINEAR REGRES
        
        # normal = data.copy()

        # for ind in list(data.index):
        #     serie = data.loc[ind,:]
        #     first = data.loc[ind,list(data.columns)[0]]
        #     norm = serie/first
        #     normal.loc[ind,:] = norm

        a_vector = []
        b_vector = []
        
        for ind in list(data.index):
            
            if verbose:
                print('Linreg...',ind)
            
            vector = np.asarray(data.loc[ind,:])
            
            x = np.arange(len(vector))
            y = vector

            linreg = LinearRegression()
            linreg.fit(x.reshape(-1,1), y) 

            b = linreg.coef_[0]
            a = linreg.intercept_
            
            a_vector.append(a)
            b_vector.append(b)
        
        hs = pd.concat([mean,std],axis=1)
        hs.columns = ['mean','std']
        hs['alpha'] = a_vector
        hs['beta'] = b_vector
        
        self.hsres = hs
        
    def CONCAT_TERMS(self):
        
        rat = pd.concat([self.dat,self.conf['conf_at']],axis=1)
        rat.columns = ['value_at','conf_at']
      
        rcp = pd.concat([self.cpres,self.conf['conf_cp']],axis=1)
        rcp.columns = ['mean_cp','std_cp','alpha_cp','beta_cp','conf_cp']

        rmp = pd.concat([self.mpres,self.conf['conf_mp']],axis=1)
        rmp.columns = ['mean_mp','std_mp','alpha_mp','beta_mp','conf_mp']

        rlp = pd.concat([self.lpres,self.conf['conf_lp']],axis=1)
        rlp.columns = ['mean_lp','std_lp','alpha_lp','beta_lp','conf_lp']        
        
        rhs = pd.concat([self.hsres,self.conf['conf_hs']],axis=1)
        rhs.columns = ['mean_hs','std_hs','alpha_hs','beta_hs','conf_hs']
        
        term_res = {'at':rat,'cp':rcp,'mp':rmp,'lp':rlp,'hs':rhs}
        
        self.terms_dict = term_res
        
    def FILTRATE_TERMS(self,penalize=0.75):
        
        pmconf = self.pmconf
        ibool= {}
        
        if pmconf['conf_at'] >= penalize:
            ibool['at'] = True
        else:
            ibool['at'] = False
        
        if pmconf['conf_cp'] >= penalize:
            ibool['cp'] = True
        else:
            ibool['cp'] = False

        if pmconf['conf_mp'] >= penalize:
            ibool['mp'] = True
        else:
            ibool['mp'] = False
            
        if pmconf['conf_lp'] >= penalize:
            ibool['lp'] = True
        else:
            ibool['lp'] = False
            
        if pmconf['conf_hs'] >= penalize:
            ibool['hs'] = True
        else:
            ibool['hs'] = False
            
        
        df = pd.DataFrame(index = self.data.index)
        
        if ibool['at']:
            df = pd.concat([df,self.terms_dict['at']],axis=1)
        else:
            self.cleaned += 1
            
        if ibool['cp']:
            df = pd.concat([df,self.terms_dict['cp']],axis=1)
        else:
            self.cleaned += 1
            
        if ibool['mp']:
            df = pd.concat([df,self.terms_dict['mp']],axis=1)
        else:
            self.cleaned += 1

        if ibool['lp']:
            df = pd.concat([df,self.terms_dict['lp']],axis=1)
        else:
            self.cleaned += 1

        if ibool['hs']:
            df = pd.concat([df,self.terms_dict['hs']],axis=1)
        else:
            self.cleaned += 1        

        cmc = pd.DataFrame(self.cmconf,columns=['country_conf'])
        df = pd.concat([df,cmc],axis=1)
        
        cols = [self.code+'_'+x for x in list(df.columns)]
        df.columns = cols
        
        self.output = df
        
class RUN_ANALISIS:
    
    def __init__(self,VARS_DF,IN_FILE, CODES_LIST, penalize=0.75,verbose=1):
        """
        IN_FILE = Path of the file to load Vars from sheet
        VARS_DF = DataFrame with Var_code as index, Var_Type and Var_name as columns
        CODES_LIST = List with country codes for initial filter
        penalize = Confidence penalization of Data (above this level is included)
        verbose = Verbosity level. 0=Nothing - 1=Vars - 2=Vars_process - 3=Vars_Linreg
        """
        self.infile = in_file
        self.VARS_DF = VARS_DF
        self.CODES = CODES_LIST
        self.plevel = penalize
        self.vlevel = verbose
        
        self.varlist = list(VARS_DF.index)
        self.resdict = {}
        self.output = pd.DataFrame()
        
    def run(self):
        
        v = self.vlevel
        
        if v > 2:
            v_reg = True
        else:
            v_reg = False
            
        for var in self.varlist:
            
            if v>0:
                print('---------------------------------')
                print('Running Analizing',var,'...')
                print('---------------------------------')
                
            if v>1:
                print('... Creating Class')
            VAR = VARIABLE(var,self.VARS_DF,self.infile,self.CODES)
            
            if v>1:
                print('... Studying')        
            VAR.STUDY()
            
            if v>1:
                print('... Cleaning Missing Values')   
            VAR.CLEAN_MSV()
            
            if v>1:
                print('... Calculating Short Term')   
            VAR.GET_CP(verbose=v_reg)
            
            if v>1:
                print('... Calculating Medium Term')   
            VAR.GET_MP(verbose=v_reg)
            
            if v>1:
                print('... Calculating Long Term')   
            VAR.GET_LP(verbose=v_reg)
            
            if v>1:
                print('... Calculating Historic')   
            VAR.GET_HS(verbose=v_reg)
            
            if v>1:
                print('... Concatenating All Terms')   
            VAR.CONCAT_TERMS()
            
            if v>1:
                print('... Selecting Terms')   
            VAR.FILTRATE_TERMS(penalize=self.plevel)
            
            outDF = VAR.output

            if v>1:
                print('... Saving Results!')           
            if VAR.cleaned < 5:
                self.resdict[var] = outDF 
            
        cconf_df = pd.DataFrame(index=self.resdict.keys())
        for var in self.resdict.keys():
            cconf = self.resdict[var].iloc[:,-1]
            cconf_df = pd.concat([cconf_df,cconf],axis=1)
        
        cconf_mean = cconf_df.mean(axis=1)
        selected = []
        
        for country in list(cconf_mean.index):
            if cconf_mean.loc[country]>=0.5:
                selected.append(country)
        
        for var in self.resdict.keys():
            self.resdict[var] = self.resdict[var].loc[selected,:]
        
        if v > 0:
            print('... Done!')
    
    def save(self,OUT_FILE):
        
        selected = list(self.resdict.keys())
        
        df = self.resdict[selected[0]].iloc[:,:-1]
        
        for var in selected[1:]:
            df = pd.concat([df,self.resdict[var].iloc[:,:-1]],axis=1)
            
        df.to_excel(OUT_FILE)
        

#%% RUNNING

ratios = RUN_ANALISIS(VARS_DF, IN_FILE=in_file, CODES_LIST=COUNTRY_CODES)
ratios.run()
ratios.save(out_file)
