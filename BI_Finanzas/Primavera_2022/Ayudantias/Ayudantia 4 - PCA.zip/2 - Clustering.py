# -*- coding: utf-8 -*-
"""
Created on Fri Nov  4 14:12:04 2022

@author: Andriu
"""

#%% IMPORTAR LIBRERIAS

import numpy as np
import pandas as pd

from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

import plotly.express as px
from plotly.offline import plot as offplot

#%% LOAD DATA

df = pd.read_excel('BD_Ratios_Mundo.xlsx')
df.set_index('ID',drop=True,inplace=True)

#%% ZSCORE

zscaler = StandardScaler()
dfz = zscaler.fit_transform(df)
dfz = pd.DataFrame(dfz,index=df.index,columns=df.columns)

#%% CLUSTERING

max_k = 25

results = {}
ressil = {}

for k in range(2,max_k+1):
    print('KMeans with k=',k,'...')
    kmeans = KMeans(k,random_state=14)
    kmeans.fit(dfz)
    labels = kmeans.predict(dfz)
    
    sil = silhouette_score(dfz, labels)
    results[k] = labels
    ressil[k] = sil
    
#%% OPTIMIZING

silDF = pd.DataFrame(ressil.values(),index=ressil.keys(),columns=['SCORE'])
silDF.sort_values('SCORE',ascending=False,inplace=True)

best_bysil = results[list(silDF.index)[0]]
best_bychoice = results[list(silDF.index)[1]]

dfb_sil = df.copy()
dfb_sil['CLUSTER'] = best_bysil # Solo un grupo gigante y otro diminuto
dfb_sil.sort_values(by='CLUSTER',ascending=False,inplace=True)

dfb_choice = df.copy() # Segunda mejor opción segun silueta
dfb_choice['CLUSTER'] = best_bychoice

#%% CENTROIDES

cent = dfb_choice.groupby('CLUSTER').mean()
cent = cent.T
ncent = dfb_choice.groupby('CLUSTER').count().mean(axis=1).to_frame()
ncent = ncent.T
ncent.index = ['N']
cent = pd.concat([ncent,cent],axis=0)

dfb_choice.to_excel('OUTPUT/CLUSTERING/CLUSTERS.xlsx')
cent.to_excel('OUTPUT/CLUSTERING/CENT.xlsx')
