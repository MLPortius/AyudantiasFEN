# -*- coding: utf-8 -*-
"""
Created on Sun Nov  6 02:11:43 2022

@author: Andriu
"""

#%% IMPORTAR LIBRERIAS

import pandas as pd
import numpy as np

from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

import plotly.express as px
from plotly.offline import plot as offplot

#%% CARGAR DATOS

# COUNTRIES VISUALIZATION
df = pd.read_excel('OUTPUT/CLUSTERING/CLUSTERS.xlsx')
df.set_index('ID',drop=True,inplace=True)

clust = df.iloc[:,-1]
df = df.iloc[:,:-1]

#%% ZSCORE

zscaler = StandardScaler()

dfz = zscaler.fit_transform(df)
dfz = pd.DataFrame(dfz,index=df.index,columns=df.columns)

#%% ENTRENAMIENTO PCA

PCA_2D = PCA(n_components=2,random_state=14) # Configuro PCA
PCA_2D.fit(dfz) # Entreno PCA
dfp = PCA_2D.transform(dfz) # Aplico PCA

# Adorno el DataFrame
dfp = pd.DataFrame(dfp,index=df.index)
dfp.columns = ['FACTOR_1','FACTOR_2']
dfp['NAMES'] = dfp.index
dfp['CLUSTER'] = clust.astype(str)  # Concateno el numero como un texto


PCA_3D = PCA(n_components=3,random_state=14)
PCA_3D.fit(dfz)
dfp2 = PCA_3D.transform(dfz)

dfp2 = pd.DataFrame(dfp2,index=df.index)
dfp2.columns = ['FACTOR_1','FACTOR_2','FACTOR_3']
dfp2['NAMES'] = dfp.index
dfp2['CLUSTER'] = clust.astype(str) # Concateno el numero como un texto 

#%% GRAFICANDO INICIALMENTE

fig2d = px.scatter(dfp,x='FACTOR_1',y='FACTOR_2',hover_data=['NAMES'],color='CLUSTER')
offplot(fig2d)

fig3d = px.scatter_3d(dfp2,x='FACTOR_1',y='FACTOR_2',z='FACTOR_3',hover_data=['NAMES'],color='CLUSTER')
offplot(fig3d)

#%% CONFIGURANDO LOS GRAFICOS

def GENERATE_AXIS(data,step):
    if max(data) >= min(data):
        v = np.abs(int(max(data))) + step
    else:
        v = np.abs(int(min(data))) + step
    return v

xdata = dfp['FACTOR_1']
ydata = dfp['FACTOR_2']
clusters = dfp['CLUSTER']

xaxis = GENERATE_AXIS(xdata,step=1)
yaxis = GENERATE_AXIS(ydata,step=2)

#%% GRAFICO INTERACTIVO
# https://plotly.com/python/builtin-colorscales/
# pip install -U kaleido

fig = px.scatter(dfp,x='FACTOR_1',y='FACTOR_2',hover_data=['NAMES','CLUSTER'],
                 color='CLUSTER',width=1200,height=600)
fig.update_layout(title={'text':'GRAFICO DE CLUSTERS CON PCA','xanchor':'center','x':0.5},plot_bgcolor='white')
fig.update_xaxes(range=[-xaxis,xaxis],linecolor='black',gridcolor='lightgray',zerolinecolor='lightgray')
fig.update_yaxes(range=[-yaxis,yaxis],linecolor='black',gridcolor='lightgray',zerolinecolor='lightgray')
fig.update_traces(marker=dict(size=10,line=dict(width=0.5,color='black')))
fig.write_image('OUTPUT/PCA/countries2d.png')
offplot(fig)
