# -*- coding: utf-8 -*-
"""
Created on Fri Nov  4 19:35:54 2022

@author: Andriu
"""

#%% IMPORTAR LIBRERIAS

import pandas as pd
import numpy as np

from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

import plotly.express as px
from plotly.offline import plot as offplot

#%% CARGAR DATOS

# CLUSTER VISUALIZATION
dfc = pd.read_excel('OUTPUT/CLUSTERING/CENT.xlsx')
dfc = dfc.T

dfc.index = ['VARIABLE','RURALES','URBANOS','ESTANDAR',
                  'POBRES','POTENCIAS','MISSING']
dfc.columns = dfc.iloc[0,:]
dfc = dfc.iloc[1:,:]
dfc = dfc.astype(float)

#%% ZSCORE

zscaler = StandardScaler()

dfcz = zscaler.fit_transform(dfc)
dfcz = pd.DataFrame(dfcz,index=dfc.index,columns=dfc.columns)
dfcz = dfcz.iloc[:,1:]

#%% ENTRENAMIENTO PCA

PCA_2D = PCA(n_components=2,random_state=14)
PCA_2D.fit(dfcz)

dfp = PCA_2D.transform(dfcz)

dfp = pd.DataFrame(dfp,index=dfc.index)
dfp.columns = ['FACTOR_1','FACTOR_2']
dfp['N'] = dfc['N']
dfp['NAMES'] = dfp.index


PCA_3D = PCA(n_components=3,random_state=14)
PCA_3D.fit(dfcz)

dfp2 = PCA_3D.transform(dfcz)
dfp2 = pd.DataFrame(dfp2,index=dfc.index)

dfp2.columns = ['FACTOR_1','FACTOR_2','FACTOR_3']
dfp2['N'] = dfc['N']
dfp2['NAMES'] = dfp.index


#%% GRAFICANDO INICIALMENTE

fig2d = px.scatter(dfp,x='FACTOR_1',y='FACTOR_2',hover_data=['NAMES','N'])
offplot(fig2d)

fig3d = px.scatter_3d(dfp2,x='FACTOR_1',y='FACTOR_2',z='FACTOR_3',hover_data=['NAMES','N'])
offplot(fig3d)

#%% CONFIGURANDO LOS GRAFICOS

def GENERATE_AXIS(data,step):
    if max(data) >= min(data):
        v = np.abs(int(max(data))) + step
    else:
        v = np.abs(int(min(data))) + step
    return v

xdata = dfp['FACTOR_1']
ydata = dfp['FACTOR_2']
size = dfp['N']

xaxis = GENERATE_AXIS(xdata,step=1)
yaxis = GENERATE_AXIS(ydata,step=4)


#%% GRAFICO INTERACTIVO
# https://plotly.com/python/builtin-colorscales/
# pip install -U kaleido
fig = px.scatter(dfp,x='FACTOR_1',y='FACTOR_2',hover_data=['NAMES','N'],
                 color='N',color_continuous_scale='teal',
                 width=1000,height=500)
fig.update_layout(title={'text':'GRAFICO DE CLUSTERS CON PCA','xanchor':'center','x':0.5},plot_bgcolor='white')
fig.update_xaxes(range=[-xaxis,xaxis],linecolor='black',gridcolor='lightgray',zerolinecolor='lightgray')
fig.update_yaxes(range=[-yaxis,yaxis],linecolor='black',gridcolor='lightgray',zerolinecolor='lightgray')
fig.update_traces(marker=dict(size=20,line=dict(width=0.5,color='black')))
fig.write_image('OUTPUT/PCA/clusters2d.png')


