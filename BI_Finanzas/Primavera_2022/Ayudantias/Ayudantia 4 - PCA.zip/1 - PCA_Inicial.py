# -*- coding: utf-8 -*-
"""
Created on Tue Nov  8 00:47:21 2022

@author: Andriu
"""

#%% IMPORTAR LIBRERIAS

import pandas as pd
import numpy as np

from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

import plotly.express as px
from plotly.offline import plot as offplot

#%% CARGAR DATOS

df = pd.read_excel('BD_Ratios_Mundo.xlsx')
df.set_index('ID',inplace=True,drop=True)

zscaler = StandardScaler()

dfz = zscaler.fit_transform(df)
dfz = pd.DataFrame(dfz,index=df.index,columns=df.columns)

#%% ESCALAMIENTO DIMENSIONAL 2D

PCA_2D = PCA(n_components=2,random_state=14)
PCA_2D.fit(dfz)

dfp = PCA_2D.transform(dfz)

dfp = pd.DataFrame(dfp,index=df.index)
dfp.columns = ['FACTOR_1','FACTOR_2']
dfp['NAMES'] = dfp.index

fig = px.scatter(dfp,x='FACTOR_1',y='FACTOR_2',hover_data=['NAMES'])
offplot(fig)

#%% ESCALAMIENTO DIMENSIONAL 3D

PCA_3D = PCA(n_components=3,random_state=14)
PCA_3D.fit(dfz)

dfp = PCA_3D.transform(dfz)

dfp = pd.DataFrame(dfp,index=df.index)
dfp.columns = ['FACTOR_1','FACTOR_2','FACTOR_3']
dfp['NAMES'] = dfp.index

fig = px.scatter_3d(dfp,x='FACTOR_1',y='FACTOR_2',z='FACTOR_3',hover_data=['NAMES'])
offplot(fig)
