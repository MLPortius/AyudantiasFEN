# -*- coding: utf-8 -*-
"""
Created on Sun Nov  6 04:48:23 2022

@author: Andriu
"""

#%% IMPORTAR LIBRERIAS

import warnings
warnings.filterwarnings('ignore')

# DATOS
import numpy as np
import pandas as pd

# PREPROCESOS
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# MODELOS DE CLASIFICACION
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier

# METRICAS CLASIFICACION
from sklearn.metrics import classification_report
from sklearn.metrics import roc_auc_score

#%% CARGAR DATOS

df1 = pd.read_excel('BD_Ratios_TipoCambio.xlsx',sheet_name='MONEDA')
df1.set_index('ID',drop=True,inplace=True)

df2 = pd.read_excel('BD_Ratios_TipoCambio.xlsx',sheet_name='RATIOS')
df2.set_index('ID',drop=True,inplace=True)

#%% PREPARACION VARIABLE EXPLICADA

Q1 = df1['TIPO'].quantile(q=0.25)
Q2 = df1['TIPO'].quantile(q=0.75)

def QUANTIZE(x):
    if x >= Q2:
        y = 'Strong'
    elif x >= Q1:
        y = 'Middle'
    else:
        y = 'Weak'
    return y

df1['TIPO_CAT'] = df1['TIPO'].apply(QUANTIZE)
df1['TIPO_CAT'].value_counts()

dummies = pd.get_dummies(df1['TIPO_CAT'],dtype=int)

depvar = dummies['Weak'].to_frame()

data = pd.merge(depvar,df2,left_index=True,right_index=True,how='inner')

del(depvar,dummies)

#%% PREPROCESOS CLASIFICACION

Y = data.iloc[:,0]
X = data.iloc[:,1:]

# TRAIN TEST SPLIT
xtr, xts, ytr, yts = train_test_split(X,Y,test_size=0.2,random_state=14)

# ZSCORE
zscaler = StandardScaler()
xstr = zscaler.fit_transform(xtr)
xsts = zscaler.transform(xts)

xstr = pd.DataFrame(xstr,index=xtr.index,columns=xtr.columns)
xsts = pd.DataFrame(xsts,index=xts.index,columns=xts.columns)


#%% INICIALIZACION DE MODELOS

MODELS = {}

MODELS['logreg'] = LogisticRegression(random_state=14,warm_start=True)
MODELS['dtree'] = DecisionTreeClassifier(random_state=14)
MODELS['forest'] = RandomForestClassifier(random_state=14,warm_start=True)
MODELS['mlp'] = MLPClassifier(random_state=14,early_stopping=True)

#%% ENTRENAMIENTO 

# model.fit(xtraining, ytraining)

for m in list(MODELS.keys()):
    print(m,'...')
    MODELS[m].fit(xstr,ytr)

del(m)

#%% PREDICCIÓN CON LOS MODELOS

# p_training = model.predict(xtraining)
# p_testing = model.predict(xtesting)

PREDS = {}
for m in list(MODELS.keys()):
    print(m,'...')
    yptr = MODELS[m].predict(xstr)
    ypts = MODELS[m].predict(xsts)
    PREDS[m] = {'train':yptr,'test':ypts}

del(yptr,ypts,m)

#%% METRICAS DE CLASIFICACION

# report_training = classification_report(ytraining,ptrainig)
# report_training = classification_report(ytesting,ptesting)

REPORTS = {}
for m in list(MODELS.keys()):
    print(m,'...')
    report_tr = classification_report(ytr, PREDS[m]['train'],output_dict=False)
    report_ts = classification_report(yts, PREDS[m]['test'],output_dict=False)
    REPORTS[m] = {'train':report_tr,'test':report_ts}

del(report_tr,report_ts,m)

#%% APLANAR REPORTES DE CLASIFICACION

REPORTS = {}
AUC = {}
for m in list(MODELS.keys()):
    print(m,'...')
    report_tr = classification_report(ytr, PREDS[m]['train'],output_dict=True)
    report_ts = classification_report(yts, PREDS[m]['test'],output_dict=True)
    auc_tr = roc_auc_score(ytr, PREDS[m]['train'])
    auc_ts = roc_auc_score(yts, PREDS[m]['test'])
    REPORTS[m] = {'train':report_tr,'test':report_ts}
    AUC[m] = {'train':auc_tr,'test':auc_ts}


def FLATTEN(report_dict, auc, split_sample, model_name):
    split = split_sample
    
    pre_0 = report_dict['0']['precision']
    pre_1 = report_dict['1']['precision']
    
    rec_0 = report_dict['0']['recall']
    rec_1 = report_dict['1']['recall']
    
    f_0 = report_dict['0']['f1-score']
    f_1 = report_dict['1']['f1-score']
    
    s_0 = report_dict['0']['support']
    s_1 = report_dict['1']['support']
    
    acc = report_dict['accuracy']
    
    lista = [split,auc,acc,pre_0,pre_1,rec_0,rec_1,f_0,f_1,s_0,s_1]
    
    dfl = pd.DataFrame(lista)
    dfl.columns = [model_name]
    dfl.index = ['SPLIT','AUC','ACCURACY','PRECISION_0','PRECISION_1','RECALL_0','RECALL_1','F_0','F_1','SUPPORT_0','SUPPORT_1'] 
    dfl = dfl.T
    
    return dfl


F_REPORTS = []
for m in list(MODELS.keys()):
    
    r_tr = REPORTS[m]['train']
    r_ts = REPORTS[m]['test']
    auc_tr = AUC[m]['train']
    auc_ts = AUC[m]['test']
    
    fr_tr = FLATTEN(r_tr,auc_tr,'train',m)
    fr_ts = FLATTEN(r_ts,auc_ts,'test',m)
    
    F_REPORTS.append(fr_tr)
    F_REPORTS.append(fr_ts)

DFR = F_REPORTS[0]
for r in F_REPORTS[1:]:
    DFR = pd.concat([DFR,r],axis=0)

del(r,m,r_tr,r_ts,fr_tr,fr_ts,report_tr,report_ts)

# DFR.to_excel('OUTPUT/Unbalanced_Results.xlsx')

dfreg = pd.DataFrame(MODELS['logreg'].coef_,columns=MODELS['logreg'].feature_names_in_,index=['COEFS'])
dfreg = dfreg.T
dfreg['ABS'] = np.abs(dfreg)
