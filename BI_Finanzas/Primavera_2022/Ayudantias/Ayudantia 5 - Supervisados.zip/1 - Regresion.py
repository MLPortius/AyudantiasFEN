# -*- coding: utf-8 -*-
"""
Created on Sun Nov  6 02:11:23 2022

@author: Andriu
"""

#%% IMPORTAR LIBRERIAS

# DATOS
import numpy as np
import pandas as pd

# PREPROCESOS
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# MODELOS DE REGRESION
from sklearn.linear_model import LinearRegression
from sklearn.svm import LinearSVR
from sklearn.tree import DecisionTreeRegressor
from sklearn.neural_network import MLPRegressor

# METRICAS REGRESION
from sklearn.metrics import mean_squared_error


#%% CARGAR DATOS

df1 = pd.read_excel('BD_Ratios_TipoCambio.xlsx',sheet_name='MONEDA')
df1.set_index('ID',drop=True,inplace=True)

df2 = pd.read_excel('BD_Ratios_TipoCambio.xlsx',sheet_name='RATIOS')
df2.set_index('ID',drop=True,inplace=True)

#%% PREPROCESOS ALGORITMOS DE REGRESION

dfr = pd.merge(left=df1['TIPO'], right=df2,how='inner',left_index=True,right_index=True)

# TRAIN TEST SPLIT

r_tr, r_ts = train_test_split(dfr,test_size=0.2,random_state=14)

# ZSCORE

zscaler = StandardScaler()

rs_tr = zscaler.fit_transform(r_tr) # Ajusto con datos de training
rs_ts = zscaler.transform(r_ts)     # Aplico con datos de testing 

rs_tr = pd.DataFrame(rs_tr,index=r_tr.index,columns=r_tr.columns)
rs_ts = pd.DataFrame(rs_ts,index=r_ts.index,columns=r_ts.columns)

# X EXPLICATIVAS - Y EXPLICADA

ytr = rs_tr.iloc[:,0].to_frame()
xtr = rs_tr.iloc[:,1:]

yts = rs_ts.iloc[:,0].to_frame()
xts = rs_ts.iloc[:,1:]


#%% ENTRENAMIENTO ALGORITMOS DE REGRESION

linreg = LinearRegression() # ALGORITMO DE REGRESION LINEAL
linreg.fit(xtr,ytr)

yptr = linreg.predict(xtr)  # la utilizo para predecir training
ypts = linreg.predict(xts)  # la utilizo para predecir testing
linreg_results = {'train':yptr,'test':ypts}


svr = LinearSVR(random_state=14) # ALGORITMO DE SUPPORT VECTOR MACHINE
svr.fit(xtr, ytr)

yptr = svr.predict(xtr)
ypts = svr.predict(xts)
svr_results = {'train':yptr,'test':ypts}


rtree = DecisionTreeRegressor(random_state=14) # ALGORITMO ARBOL DE DECISION
rtree.fit(xtr, ytr)

yptr = rtree.predict(xtr)
ypts = rtree.predict(xts)
rtree_results = {'train':yptr,'test':ypts}


rmlp = MLPRegressor(random_state=14,early_stopping=True) # ALGORITMO DE RED NEURONAL SIMPLE
rmlp.fit(xtr, ytr)

yptr = rmlp.predict(xtr)
ypts = rmlp.predict(xts)
rmlp_results = {'train':yptr,'test':ypts}


#%% METRICAS ALGORITMOS DE REGRESION

# LINEAR REGRESION
yptr = linreg_results['train']
ypts = linreg_results['test']

rmse_tr = np.round(np.sqrt(mean_squared_error(ytr, yptr)),3)
rmse_ts = np.round(np.sqrt(mean_squared_error(yts, ypts)),3)
linreg_rmse = {'train':rmse_tr,'test':rmse_ts}

# SUPPORT VECTOR MACHINE
yptr = svr_results['train']
ypts = svr_results['test']

rmse_tr = np.round(np.sqrt(mean_squared_error(ytr, yptr)),3)
rmse_ts = np.round(np.sqrt(mean_squared_error(yts, ypts)),3)
svr_rmse = {'train':rmse_tr,'test':rmse_ts}

# ARBOL DE DECISION
yptr = rtree_results['train']
ypts = rtree_results['test']

rmse_tr = np.round(np.sqrt(mean_squared_error(ytr, yptr)),3)
rmse_ts = np.round(np.sqrt(mean_squared_error(yts, ypts)),3)
rtree_rmse = {'train':rmse_tr,'test':rmse_ts}

# RED NEURONAL SIMPLE
yptr = rmlp_results['train']
ypts = rmlp_results['test']

rmse_tr = np.round(np.sqrt(mean_squared_error(ytr, yptr)),3)
rmse_ts = np.round(np.sqrt(mean_squared_error(yts, ypts)),3)
rmlp_rmse = {'train':rmse_tr,'test':rmse_ts}

# MATRIZ
regresion = {}
regresion['linreg'] = [linreg_rmse['train'], linreg_rmse['test']]
regresion['svm'] = [svr_rmse['train'], svr_rmse['test']]
regresion['rtree'] = [rtree_rmse['train'], rtree_rmse['test']]
regresion['mlp'] = [rmlp_rmse['train'], rmlp_rmse['test']]

regresion = pd.DataFrame(regresion.values(),index=regresion.keys())
regresion.columns = ['TRAIN','TEST']

# ALGORITMO DE CAJA ABIERTA
tree_features = pd.DataFrame(rtree.feature_importances_,index=rtree.feature_names_in_,columns=['IMPORTANCE'])
tree_features.sort_values(by='IMPORTANCE',axis=0,ascending=False,inplace=True)

# ALGORITMO DE CAJA CERRADA
mlp_coefs = rmlp.coefs_

#%% RESULTADOS DESCALADOS

res_tr = pd.DataFrame(rmlp_results['train'],index=ytr.index,columns=['PREDICT'])
res_ts = pd.DataFrame(rmlp_results['test'],index=yts.index,columns=['PREDICT'])          

yscale_mean = zscaler.mean_[0]
yscale_var = zscaler.var_[0]

rmlp_res_scaled = pd.concat([res_tr,res_ts],axis=0)

rmlp_res = rmlp_res_scaled*yscale_var + yscale_mean

rmlp_res = pd.merge(rmlp_res,dfr,left_index=True,right_index=True)
rmlp_res = rmlp_res.iloc[:,:2]

rmlp_res.plot()
