# -*- coding: utf-8 -*-
"""
Created on Tue Sep 20 04:02:29 2022

@author: Andriu
"""

#%% IMPORTAR LIBRERIAS

import numpy as np
import pandas as pd

from sklearn.preprocessing import StandardScaler
from sklearn.cluster import DBSCAN
from sklearn.metrics import silhouette_score

import plotly.express as px
from plotly.offline import plot

#%% CARGAR DATOS

data = pd.read_excel('creditos_bancarios.xlsx')
data.set_index("id",drop=True,inplace=True)


#%% DATOS OK

var = ['duration','amount','age']

df1 = data.loc[:,var]

#%% MAP

var = ['people_liable','telephone','foreign_worker','credit_risk']

df2 = data.loc[:,var]

# people_liable
d = {1:1,2:0}
df2[var[0]] = df2[var[0]].map(d)

# telephone
d = {1:0,2:1}
df2[var[1]] = df2[var[1]].map(d)

# foreign_worker
d = {1:1,2:0}
df2[var[2]] = df2[var[2]].map(d)

# credit_risk
d = {0:0,1:1}
df2[var[3]] = df2[var[3]].map(d)


#%% OK PODRIA APLICARSE CRITERIO

var = ['status','credit_history','savings','employment_duration',
       'present_residence','property','number_credits','job']

df3 = data.loc[:,var]


#%% INVERSO - PODRIA APLICARSE CRITERIO	

var = ['installment_rate','other_installment_plans']

df4 = data.loc[:,var]

def INSTALLMENT(x):
    if x == 1:
        y = 4
    elif x == 2:
        y = 3
    elif x == 3:
        y = 2
    else:
        y = 1
    return y

df4[var[0]] = df4[var[0]].apply(INSTALLMENT)


def OTHER_PLANS(x):
    if x == 1:
        y = 100
    elif x == 2:
        y = 75
    else:
        y = 0
    return y

df4[var[1]] = df4[var[1]].apply(OTHER_PLANS)


#%% CRITERIO NECESARIO	

var = ['other_debtors','housing']

df5 = data.loc[:,var]

def OTHER_DEBTOR(x):
    if x == 1:
        y = 0
    elif x == 2:
        y = 75
    else:
        y = 100
    return y

df5[var[0]] = df5[var[0]].apply(OTHER_DEBTOR)

def HOUSING(x):
    if x == 1:
        y = 0
    elif x == 2:
        y = 75
    else:
        y = 100
    return y

df5[var[1]] = df5[var[1]].apply(HOUSING)


#%% DUMMIES

var = "purpose"

df6 = data.loc[:,var]

d = {0:'others',1:'car (new)',2:'car (used)',3:'furniture/equipment',
     4:'radio/television',5:'domestic appliances',6:'repairs',
     7:'education',8:'vacation',9:'retraining',10:'business'}

df6 = df6.map(d)
df6 = pd.get_dummies(df6,prefix='purpose',dtype=int)


#%% CONCATENAR DATOS

df = pd.concat([df1,df2,df3,df4,df5,df6],axis=1)
del(df1,df2,df3,df4,df5,df6,d,var)       
         

#%% 1.2 NORMALIZAR LOS DATOS

zscaler = StandardScaler()
dfz = zscaler.fit_transform(df)       

dfz = pd.DataFrame(dfz,index=df.index,columns=df.columns)

#%% 2. DBSCAN
#https://scikit-learn.org/stable/modules/generated/sklearn.cluster.DBSCAN.html

# PARA UN MODELO
model = DBSCAN(eps=3,min_samples=5)
model.fit(dfz)

labels = pd.Series(model.labels_,index=dfz.index)

sil = silhouette_score(dfz,labels,random_state=14)


# GRILLA PARA OPTIMIZAR
eps_grid = [0.05, 0.1, 0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5, 6, 7, 8, 9, 10, 
            11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 25, 30, 35, 40, 45, 50]
ms_grid = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,25,30,35,40,45,50,
           60, 70, 80, 90, 100, 150, 200, 250, 300]

grid = []
for i in eps_grid:
    for j in ms_grid:
        grid.append((i,j))

    
# ALGORITMO DE OPTIMIZACION
models = []
for g in grid:
    
    print("----",g,"----")
    
    model = DBSCAN(eps=g[0],min_samples=g[1])
    model.fit(dfz)
    labels = pd.Series(model.labels_,index=dfz.index)
    nclust = len(labels.unique())
    if nclust > 1:    
        sil = silhouette_score(dfz,labels,random_state=14)
        models.append([g[0],g[1],sil,nclust])
  
search = pd.DataFrame(models)
search.columns = ['eps','min_sample','silhouette','nclust']

#%% 3. EVALUACION

fig = px.line(search['silhouette'])
plot(fig)

fig = px.scatter(search,x='eps',y='silhouette',title='SILHOUETTE VS EPSILON')
plot(fig)

fig = px.scatter(search,x='min_sample',y='silhouette',title='SILHOUETTE VS MIN_SAMPLE')
plot(fig)

fig = px.scatter(search,x='nclust',y='silhouette',title='SILHOUETTE VS CLUSTER NUMBER')
plot(fig)

#%% 4. CENTROIDES

# MODELO OPTIMO
model = DBSCAN(eps=8,min_samples=2)
model.fit(dfz)
labels = pd.DataFrame(model.labels_,index=dfz.index,columns=['cluster'])

# CONCATENAR A LA DATA PRE ESCALADA
dfm = pd.concat([df,labels],axis=1)

cent = dfm.groupby(by='cluster').mean().T
