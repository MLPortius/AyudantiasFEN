# -*- coding: utf-8 -*-
"""
Created on Thu Aug  4 01:57:18 2022

@author: Andriu
"""

#%% Leer Tweet 

# Abrimos  el archivo de texto
with open('Tweet 1.txt') as txt:
    tweet = txt.readline()  # Leemos lo que tiene el archivo
txt.close() #Cerramos el archivo de texto

print(tweet) # Revisamos el tweet leido


#Lo convertimos en una lista con cada palabra
words = tweet.split(sep=" ")


#%% Analisis del Texto

# Comprobar cuantas palabras aparecen en el texto
n = len(words)


# Comprobar cuantas veces aparece una palabra - METODO MANUAL
words.count('alegria')


# DEFINIMOS UNA LISTA CON LAS PALABRAS A ANALIZAR
Positive = ['alegria','bueno','felicidad','feliz']
Negative = ['malo','odio','tristeza','fallar']


# Metodo desde una Lista - METODO INDICE DE LISTA
Positive[0]
words.count(Positive[0])


# Comprobar cuantas veces aparece una palabra - METODO ITERATIVO
for palabra in Positive:
    print(palabra)
    print(words.count(palabra))
    
    
# Encontrar numero de palabras positivas usando el METODO ITERATIVO
pw = 0   # En esta variable almacenaremos el numero calculado en cada vuelta
for palabra in Positive:
    pw = pw + words.count(palabra)

print('Numero de palabras positivas = ' + str(pw))


# Encontrar numero de palabras negativas usando el METODO ITERATIVO
nw = 0
for palabra in Negative:
    nw += words.count(palabra)
    
print('Numero de palabras negativas = ' + str(nw))


# CALCULAR RATIOS DE SENTIMIENTO
pratio = pw/n
nratio = nw/n


# COMPARAR RATIOS DE SENTIMIENTO 
if pratio > nratio:
    sentimiento = 'Sentimiento Positivo'
elif pratio < nratio:
    sentimiento = 'Sentimiento Negativo'
else:
    sentimiento = 'Sentimiento Neutral'
    
print(sentimiento)
    


#%% CREAR UNA FUNCION ANALIZADORA

def ANALIZAR_SENTIMIENTO(file, ListaP, ListaN):
    # Paso 1: Cargar Tweet a Leer
    with open(file) as txt:
        tweet = txt.readline()  
    txt.close() 
    
    # Paso 2: Generar una lista con las palabras del Tweet
    words = tweet.split(sep=" ")

    # Paso 3: Contar cantidad total de palabras en Tweet
    n = len(words)
    
    # Paso 4: Contar numero de Palabras Positivas
    pw = 0
    for palabra in ListaP:
        pw = pw + words.count(palabra)
    
    # Paso 5: Contar numero de Palabras Negativas
    nw = 0
    for palabra in ListaN:
        nw += words.count(palabra)
        
    # Paso 6: Calcular ratios sentimentales
    pratio = round(pw/n,3)
    nratio = round(nw/n,3)
    
    # Paso 7: Generar comparacion de ratios
    if pratio > nratio:
        sentimiento = 'Sentimiento Positivo'
    elif pratio < nratio:
        sentimiento = 'Sentimiento Negativo'
    else:
        sentimiento = 'Sentimiento Neutral'
    
    # Paso 8: Entregar Resultados segun eleccion
    print(file)
    print(sentimiento)
    print('Pratio: '+str(pratio))
    print('Nratio: '+str(nratio))

#%% APLICAR FUNCION CREADA A LOS TWEETS DISPONIBLES

Positive = ['alegria','bueno','felicidad','feliz']
Negative = ['malo','odio','tristeza','fallar']
    
# Entregar Ratios de Sentimiento
ANALIZAR_SENTIMIENTO(file='Tweet 1.txt', ListaP=Positive, ListaN=Negative)
ANALIZAR_SENTIMIENTO(file='Tweet 2.txt', ListaP=Positive, ListaN=Negative)
ANALIZAR_SENTIMIENTO(file='Tweet 3.txt', ListaP=Positive, ListaN=Negative)


#%% ITERACION PARA ANALIZAR MULTIPLES TWEETS

Lista_Tweets = ['Tweet 1.txt','Tweet 2.txt','Tweet 3.txt']

for elemento in Lista_Tweets:
    print('....................')
    ANALIZAR_SENTIMIENTO(file=elemento, ListaP=Positive, ListaN=Negative)
    print('....................')



