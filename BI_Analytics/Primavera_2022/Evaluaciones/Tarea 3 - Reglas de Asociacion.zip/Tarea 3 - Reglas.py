# -*- coding: utf-8 -*-
"""
Created on Sun Nov  6 16:57:03 2022

@author: Andriu
"""

#%% IMPORTAR LIBRERIAS

import pandas as pd
import numpy as np

import plotly.express as px
from plotly.offline import plot as offplot

from mlxtend.frequent_patterns import apriori                # Carga libreria de patrones frecuentes apriori
from mlxtend.frequent_patterns import association_rules      # Carga libreria reglas de asociación

import datetime as dt

#%% CARGAR DATOS

df = pd.read_excel('BD_compras_online.xlsx')
df.set_index('Order_ID',drop=True,inplace=True)
df.drop('Customer',axis=1,inplace=True)

df_info = df.iloc[:,:2]
df = df.iloc[:,2:]

data = pd.DataFrame(index=df.index)


#%% PREPROCESOS - VARIABLES NUMERICAS CONTINUAS

# qcut: Corte de Quantil (%)
# cut: Corte de Rango (#)


# MONTO DE COMPRA 
amount = df['Total_Amount']
amountDF = amount.to_frame()

pd.qcut(amount,7).value_counts()
pd.cut(amount,7).value_counts()

# Aplicar Transformacion
def Q_AMOUNT(x):
    if x <= 10000:
        y = 'Small_Amount'
    elif x <= 100000:
        y = 'Middle_Amount'
    elif x <= 500000:
        y = 'Big_Amount'
    else:
        y = 'Prime_Amount'
    return y

amountDF['CAT'] = amount.apply(Q_AMOUNT)
amountDF['CAT'].value_counts()

amountDummy = pd.get_dummies(amountDF['CAT'],dtype=int)

# NUMERO DE ITEMS EN EL CARRO
iio = df['ItemsInOrder']
iioDF = iio.to_frame()

pd.qcut(iio,4,duplicates='drop').value_counts()  # NO SIRVE MUY BIEN
pd.cut(iio,5).value_counts()                     # NO SIRVE MUY BIEN                    


# Metodo Grafico
iioDF = iio.to_frame()
iioDF['ID'] = iioDF.index
iioCOUNT = iioDF.groupby(by='ItemsInOrder').count()

# fig = px.bar(iioCOUNT)
# offplot(fig)

# Aplicar Transformacion
def Q_ITEMS(x):
    if x == 1:
        y = 'Unico_Item'
    elif x <= 10:
        y = 'Pocos_Item'
    elif x <= 20:
        y = 'Varios_Item'
    else:
        y = 'Muchos_Item'
    return y

iioDF['CAT'] = iioDF['ItemsInOrder'].apply(Q_ITEMS)
iioDF['CAT'].value_counts()

iioDummy = pd.get_dummies(iioDF['CAT'],dtype=int)

# Concateno Resultados
data = pd.concat([data,amountDummy,iioDummy],axis=1)


#%% PREPROCESOS - VARIABLES NOMINALES CATEGORICAS

eco = df['Ecosystem']
eco.value_counts()

ecoDummy = pd.get_dummies(eco,prefix='Platform',dtype=int)

data = pd.concat([data,ecoDummy],axis=1)

#%% PREPROCESOS - VARIABLES NOMINALES BINARIAS

for var in list(df.iloc[:,4:].columns):
    t = df[var]
    d = pd.get_dummies(t,dtype=int)
    data = pd.concat([data,d],axis=1)

#%% PREPROCESOS - VARIABLES NOMINALES CATEGORICAS MEZCLADAS

t0 = df['T0']
t0.unique()

v1 = 'Appliances'
v2 = 'Photography'
v3 = 'TV/Audio/Video'

cols = []
for ind in list(t0.index):
    
    l = [0,0,0]
    
    var1 = t0[ind].split(',')[0]
    var2 = t0[ind].split(',')[1]
    var3 = t0[ind].split(',')[2]
    
    if var1 == v1:
        l[0] = 1
    if var2 == v2:
        l[1] = 1
    if var3 == v3:
        l[2] = 1
    
    cols.append(l)
    
t0d = pd.DataFrame(cols)
t0d.index = t0.index
t0d.columns = [v1,v2,v3]

data = pd.concat([data,t0d],axis=1)

#%% REGLAS DE ASOCIACION - VARIABLES

# pip install mlxtend

# Llevo todo a booleano

def BOOLEANO(x):
    if x==1:
        y = True
    else:
        y = False
    return y

for var in list(data.columns):
    data[var] = data[var].apply(BOOLEANO)


#%% REGLAS DE ASOCIACION 

# CON VARIABLES DE COMPRA

# Calculo la frecuencia (soporte) de cada ítem por separado y en conjunto con los otros, dado un soporte mínimo deseado
frequent_itemsets = apriori(data, min_support=0.01, use_colnames=True)
rules = association_rules(frequent_itemsets, metric="lift", min_threshold=1)

def TO_TEXT(x):
    y = str(list(x))
    return y

rules['antecedents'] = rules['antecedents'].apply(TO_TEXT)
rules['consequents'] = rules['consequents'].apply(TO_TEXT)
rules.sort_values('lift',ascending=False,inplace=True)
rules.to_excel('Reglas_1.xlsx')



#%% REGLAS DE ASOCIACION 2

timeDF = df_info['Time'].to_frame()
type(timeDF.iloc[0,0])

# Pruebo con una:
t = timeDF.iloc[0,0]    # Obtengo el tiempo a trabajar
h = t.split(':')[0]     # Extraigo la hora del dia (formato 24 horas)
h = int(h)              # Paso la hora a numero

# Trasformo toda la columna
def TimeHour(x):
    y = x.split(':')[0]
    y = int(y)
    return y

timeDF['Hour'] = timeDF['Time'].apply(TimeHour)

# Llevo a categorico
def HourCat(x):
    if x <= 2:
        y = 'Noche'
    elif x <= 6:
        y = 'Madrugada'
    elif x <= 12:
        y = 'Mañana'
    elif x <= 16:
        y = 'Dia'
    elif x <= 20:
        y = 'Tarde'
    elif x <= 24:
        y = 'Noche'
    return y

timeDF['Timing'] = timeDF['Hour'].apply(HourCat)
timeDummy = pd.get_dummies(timeDF['Timing'],prefix='Time',dtype=int)

for var in list(timeDummy.columns):
    timeDummy[var] = timeDummy[var].apply(BOOLEANO)

data2 = pd.concat([data,timeDummy],axis=1)


# Reglas de Asociacion
frequent_itemsets = apriori(data2, min_support=0.01, use_colnames=True)
rules = association_rules(frequent_itemsets, metric="lift", min_threshold=2)

rules['antecedents'] = rules['antecedents'].apply(TO_TEXT)
rules['consequents'] = rules['consequents'].apply(TO_TEXT)
rules.sort_values('lift',ascending=False,inplace=True)
rules.to_excel('Reglas_2.xlsx')

#%% REGLAS DE ASOCIACION BONUS

# https://www.programiz.com/python-programming/datetime/strptime

dateDF = df_info['Date'].to_frame()
type(dateDF.iloc[0,0]) # Esta en formato texto

# Pruebo llevando un dato a formato datetime
d = dateDF.iloc[0,0]
dtime = dt.datetime.strptime(d,'%Y-%m-%d') 
wday = dtime.weekday()

# Lo aplico a toda la cadena
def WeekDay(x):
    dtime = dt.datetime.strptime(x,'%Y-%m-%d') 
    y = dtime.weekday()
    return y

dateDF['WDay'] = dateDF['Date'].apply(WeekDay)

# Llevo a categorico
def WdayCat(x):
    if x <= 3:
        y = 'EarlyWeek'
    elif x <= 5:
        y = 'MidWeek'
    elif x <= 7:
        y = 'Weekend'
    return y

dateDF['CAT'] = dateDF['WDay'].apply(WdayCat)
dateDummy = pd.get_dummies(dateDF['CAT'],prefix='WDAY',dtype=int)

for var in list(dateDummy.columns):
    dateDummy[var] = dateDummy[var].apply(BOOLEANO)

data3 = pd.concat([data,dateDummy],axis=1)

# Reglas de Asociacion
frequent_itemsets = apriori(data3, min_support=0.01, use_colnames=True)
rules = association_rules(frequent_itemsets, metric="lift", min_threshold=2)

rules['antecedents'] = rules['antecedents'].apply(TO_TEXT)
rules['consequents'] = rules['consequents'].apply(TO_TEXT)
rules.sort_values('lift',ascending=False,inplace=True)
rules.to_excel('Reglas_Bonus.xlsx')

