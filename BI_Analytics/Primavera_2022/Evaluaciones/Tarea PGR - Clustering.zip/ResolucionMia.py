# -*- coding: utf-8 -*-
"""
Created on Mon Oct 31 19:01:36 2022

@author: Andriu
"""

import pandas as pd
import numpy as np


#%%

df = pd.read_excel('Asistencia_PGR.xlsx') #leo datos

df.set_index('id_colaborador',drop=True,inplace=True) #defino indice


listasinrepetir = list(set(list(df.index))) # saco la lista sin colaboradores repetidos
listasinrepetir.sort() # ordeno la lista

df2 = pd.DataFrame(index=listasinrepetir) # creo el dataframe sin repeticiones


# hago una nueva lista, donde para cada colaborador se guardará su dato correcto (digamos que es la suma de los dias trabajados en total)

data_junta = []
for colab in listasinrepetir:
    # dentro del for haré los calculos o arreglos necesarios
    data_separada = df.loc[colab,'Dias Trabajados'] # extraigo la columna, para ese colaborador
    suma = data_separada.sum() # calculo la suma de los dias
    data_junta.append(suma) # la guardo en otra lista

del(data_separada, suma, colab) # elimino lo restante para ser ordenado


# hago que esta lista sea una columna del dataframe sin repetir

df2['Dias_Trabajados_Total'] = data_junta


#%% PARA LA COLUMNA GENERO

df['genero'].unique()

df['genero_num'] = df['genero'].map({'M':0,'F':1})

data_junta = []
for colab in listasinrepetir:
    data_separada = df.loc[colab,'genero_num']
    g_unico = data_separada.mean()
    data_junta.append(g_unico)
    
df2['Genero'] = data_junta


