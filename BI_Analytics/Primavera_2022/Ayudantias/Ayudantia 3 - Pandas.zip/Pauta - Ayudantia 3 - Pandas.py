# -*- coding: utf-8 -*-
"""
Created on Thu Sep 15 12:52:19 2022

@author: Andriu
"""

#%% IMPORTAR LIBRERIAS

import numpy as np
import pandas as pd

#%% 2. CARGAR DATOS

data = pd.read_excel('BD_empresa.xlsx')
data.set_index('ID',drop=True,inplace=True)

#%% 3. MODIFICAR EL INDICE A TRAVÉS DE FOR

ID = list(data.index)

new_ID = []
for ind in ID:
    new_ind = "id_"+str(ind)
    new_ID.append(new_ind)

data.index = new_ID

#%% 4. MAP BINARIO

# SI COMPRUEBO, TODA LA INFORMACIÓN ES UN DATAFRAME
data
type(data)

# AL EXTRAER UNA COLUMNA, ESTA SE VUELVE UNA SERIES
data['ED_SUPERIOR']
type(data['ED_SUPERIOR'])

# MAP SE OCUPA PARA REEMPLAZAR VALORES EN UNA SERIE, NO SE PUEDE OCUPAR EN UN DATAFRAME
# COMO MAP NO FUNCIONA EN DATAFRAMES, SE PUEDE UTILIZAR APPLY PARA REEMPLAZAR

# MAP UTILIZA UN DICCIONARIO PARA SABER QUE REEMPLAZAR
# APPLY UTILIZA UNA FUNCION PERSONALIZADA PARA SABER QUE REEMPLAZAR
data['ED_SUPERIOR'].unique()

diccionario = {'no':0,'si':1}

data['ED_SUPERIOR_NUM'] = data['ED_SUPERIOR'].map(diccionario)

diccionario = {'chileno':0,'extranjero':1}

data['NACIONALIDAD_NUM'] = data['NACIONALIDAD'].map(diccionario)


#%% 5. APPLY ORDINAL

def EXP_NOMINAL(x):
    if x < 1:
        y = "Sin Experiencia"
    elif x < 5:
        y = "Junior"
    elif x < 15:
        y = "Intermediate"
    elif x >= 15:
        y = "Senior"
    return y

data['EXP_RUBRO_NOMINAL'] = data['EXP_RUBRO'].apply(EXP_NOMINAL)


diccionario = {'Sin Experiencia':0,'Junior':1,'Intermediate':2,'Senior':3}

data['EXP_RUBRO_ORDINAL'] = data['EXP_RUBRO_NOMINAL'].map(diccionario)

#%% 6. GET DUMMIES

data['AREA']

AREA_DUMMY = pd.get_dummies(data['AREA'],prefix='AREA',dtype=int)

data = pd.concat([data,AREA_DUMMY],axis=1)

#%% 7. VARIABLE CUADRATICA

data['EDAD']

def CUADRATICA(x):
    y = x**2
    return y

data['EDAD^2'] = data['EDAD'].apply(CUADRATICA)


#%% 8. VARIABLE DE INTERACCION

data['EDAD']
data['EXP_RUBRO']

data['INT_EDAD_EXP'] = data['EDAD']*data['EXP_RUBRO']

#%% 9. ESCALA UTILIZANDO MAP

data['GENERO'].unique()

diccionario = {'hombre':-1, 'otro':0, 'mujer':1}
data['GENERO_NUM'] = data['GENERO'].map(diccionario)

#%% REORDENANDO EL DATAFRAME

lista = ['SALARIO','N_HIJOS','NACIONALIDAD','NACIONALIDAD_NUM',
         'ED_SUPERIOR','ED_SUPERIOR_NUM','GENERO','GENERO_NUM',
         'EDAD', 'EDAD^2','INT_EDAD_EXP','EXP_RUBRO','EXP_RUBRO_NOMINAL','EXP_RUBRO_ORDINAL',
         'AREA','AREA_BI','AREA_TI','AREA_finanzas','AREA_logistica','AREA_marketing','AREA_rrhh']

data = data.loc[:,lista]

data.to_excel('BD_empresa_mod.xlsx')

#%% 10. GROUP BY 

lista_td1 = ['EXP_RUBRO_NOMINAL','AREA_BI','AREA_TI','AREA_finanzas',
             'AREA_logistica','AREA_marketing','AREA_rrhh']

data_td1 = data.loc[:,lista_td1]

td1 = data_td1.groupby(by='EXP_RUBRO_NOMINAL', axis=0, as_index=True, sort=True).sum()



lista_td2 = ['GENERO','SALARIO','EDAD','EXP_RUBRO']

data_td2 = data.loc[:,lista_td2]

td2 = data_td2.groupby(by='GENERO', axis=0, as_index=True, sort=True).mean()


#%% 11. PLOTLY EXPRESS

import plotly.express as px
from plotly.offline import plot

# SERIES SEPARADAS
fig = px.bar(td2,title='PROMEDIOS POR GENERO')
plot(fig)

# SERIES AGRUPADAS
fig = px.bar(td2,title='PROMEDIOS POR GENERO',barmode='group')
plot(fig)

# SERIES AGRUPADAS - MISMA ESCALA
td2n = td2/td2.max()

fig = px.bar(td2n,title='PROMEDIOS POR GENERO',barmode='group')
fig.update_xaxes(title ='Genero')
fig.update_yaxes(title ='Data')
plot(fig)

# SERIES AGRUPADAS - MISMA ESCALA - COMPARABLES
fig = px.bar(td2n.T,title='PROMEDIOS POR GENERO',barmode='group', color_discrete_sequence=["crimson", "seagreen", "blueviolet"])
fig.update_xaxes(title ='Genero')
fig.update_yaxes(title ='Data')
plot(fig)

# SERIES AGRUPADAS - MISMA ESCALA - COMPARABLES - SELECCION DE COLORES
fig = px.bar(td2n.T,title='PROMEDIOS POR GENERO',barmode='group', 
             color_discrete_sequence=["crimson", "seagreen", "blueviolet"])
fig.update_xaxes(title ='Genero')
fig.update_yaxes(title ='Data')
plot(fig)

# EXPORTAR EL GRÁFICO
# https://plotly.com/python/static-image-export/
# !pip install --upgrade "kaleido==0.1.*"


# PARA FORMATO TRADICIONAL
fig.write_image("plotly_image.png")

# PARA IMAGEN VECTORIZADA (No pierde calidad en cualquier tamaño)
fig.write_image("plotly_image.svg")

# PARA GUARDAR EL GRAFICO INTERACTIVO
fig.write_html("plotly_image.html")


#%% 12. VARIABLES NUMERICAS

num_var = []

for ind in list(data.columns):
    if not (data.loc[:,ind].dtype == "object"):
        num_var.append(ind)

data = data.loc[:,num_var]

ydata = data.loc[:,'SALARIO'].to_frame()/1000
xdata = data.drop('SALARIO',axis=1)

#%% TEST DE NORMALIDAD CON SCIPY

from scipy.stats import shapiro

# TEST DE SHAPIRO WILKS

#https://bookdown.org/dietrichson/metodos-cuantitativos/test-de-normalidad.html
#https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.shapiro.html#scipy.stats.shapiro

# H0 = NORMAL - p-value >= 0.05
# H1 = NO NORMAL - p-value < 0.05

shapiro(data).pvalue

if shapiro(data).pvalue < 0.05:
    print("los datos no son normales")
else:
    print("los datos son normales")


#%% REGRESION LINEAL CON STATSMODELS

import statsmodels.api as sm

# SE AÑADE UNA COLUMNA PARA ESTIMAR LA CONSTANTE
xdatac = sm.add_constant(xdata)

# AJUSTE REGRESION LINEAL SIN ROBUSTEZ
model = sm.OLS(ydata,xdatac)
results = model.fit()
results.summary()

# AJUSTE CON MODELO ROBUSTO
model = sm.RLM(ydata,xdatac)
results2 = model.fit()
results2.summary()

# SE GUARDA EN UN TXT
with open('linreg_summary.txt', 'w') as txt:
    print(results.summary(),file=txt)
    print(results2.summary(),file=txt)  
txt.close()


