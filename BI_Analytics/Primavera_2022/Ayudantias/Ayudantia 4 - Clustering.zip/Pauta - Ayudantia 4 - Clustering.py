# -*- coding: utf-8 -*-
"""
Created on Sat Oct 22 13:50:49 2022

@author: Andriu
"""

#%% IMPORTAR LIBRERIAS

import numpy as np
import pandas as pd

from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.cluster import DBSCAN
from sklearn.metrics import silhouette_score

import plotly.express as px
from plotly.offline import plot as offplot

from datetime import datetime as dt

#%% CARGAR DATOS

df = pd.read_excel('BD_vacaciones.xlsx')


#%% PREPROCESOS - DEFINIR INDICE

df.set_index('ID',drop=True,inplace=True)


#%% DESCARTAR

df.drop(columns=['INFO_EXTRA'],inplace=True)

#%% PREPROCESOS - SIN PREPROCESO

var1 = ['EDAD','N_HIJOS','EXP_RUBRO','SALARIO',
        'DIAS_VACACIONES_ACUMULADOS']

df1 = df.loc[:,var1]

del(var1)

#%% PREPROCESOS - MAP BINARIO

var2 = ['NACIONALIDAD']

df2 = df.loc[:,var2]

df2['NACIONALIDAD'].unique()

dict2 = {'chileno':0,'extranjero':1}

df2['NACIONALIDAD'] = df2['NACIONALIDAD'].map(dict2) 

del(var2,dict2)


#%% PREPROCESOS - ESCALA

var3 = ['ESTADO_MARITAL','MES_NACIMIENTO']

df3 = df.loc[:,var3]

# ESTADO_MARITAL
dict3 = {'soltero/a':0,'divorciado/a':30,'viudo/a':60,'casado/a':100}

df3['ESTADO_MARITAL'] = df3['ESTADO_MARITAL'].map(dict3)

# MES_NACIMIENTO
dict3 = {'enero':0,'febrero':9,'marzo':18,'abril':27,'mayo':36,'junio':45,
         'julio':55,'agosto':64,'septiembre':73,'octubre':82,
         'noviembre':91,'diciembre':100}

df3['MES_NACIMIENTO'] = df3['MES_NACIMIENTO'].map(dict3)

del(var3,dict3)

#%% PREPROCESOS - DUMMIES

var4 = ['AREA','GENERO','TIPO_VIAJE']

df4 = df.loc[:,var4]

# AREA
df4['AREA'].unique()
df4_1 = pd.get_dummies(df4['AREA'],prefix='AREA',dtype=int)

# GENERO
df4['GENERO'].unique()
df4_2 = pd.get_dummies(df4['GENERO'],prefix='GENERO',dtype=int)
df4_2 = df4_2.iloc[:,[0,1]]

# TIPO_VIAJE
df4['TIPO_VIAJE'].unique()
df4_3 = pd.get_dummies(df4['TIPO_VIAJE'],prefix='VIAJE',dtype=int)
df4_3 = df4_3.iloc[:,[0,1]]

# CONCATENAR
df4 = pd.concat([df4_1,df4_2,df4_3],axis=1)

del(var4,df4_1,df4_2,df4_3)

#%% PREPROCESOS - DEMAP + DUMMIES

var5 = ['LUGAR_VACACIONES']
df5 = df.loc[:,var5]

dict5 = {0:'domicilio',1:'playa',2:'campo',3:'montaña',4:'crucero'}
df5['LUGAR_VACACIONES'] = df5['LUGAR_VACACIONES'].map(dict5)

df5 = pd.get_dummies(df5['LUGAR_VACACIONES'],prefix='LUGAR',dtype=int)

del(var5,dict5)

#%% PREPROCESOS - CATEOGORICO A ESCALA

var6 = ['EDUCACION']
df6 = df.loc[:,var6]

dict6 = {1:0,2:50,3:85,4:100}
df6['EDUCACION'] = df6['EDUCACION'].map(dict6)

del(var6,dict6)

#%% PREPROCESOS - FECHAS A DIAS

var7 = ['ULTIMAS_VACACIONES','FECHA_CONTRATACION'] 
df7 = df.loc[:,var7]

# TIPO DE LOS DATOS
df7.dtypes #datetime64

# FECHA DE HOY
now = dt.now()

now.year        # AÑO
now.month       # MES
now.day         # DIA
now.hour        # HORA
now.minute      # MINUTO
now.second      # SEGUNDO

now.date()      # FECHA (AÑO, MES, DIA)
now.time()      # TIEMPO (HORA, MINUTO, SEGUNDO, MILISEGUNDO)


# ULTIMAS_VACACIONES

fechas = list(df7['ULTIMAS_VACACIONES']) 

# formato original
print('Tipo Hoy: ', type(now.date()))
print('Tipo Dato: ',type(fechas[0]))

# https://pandas.pydata.org/docs/reference/api/pandas.Timestamp.html

fechas_new = [f.date() for f in fechas]

# formato nuevo
print('Tipo Hoy: ',type(now.date()))
print('Tipo Dato: ',type(fechas_new[0]))
    
# diferencia de dias
deltas = [now.date()-f for f in fechas_new]
days_list = [d.days for d in deltas]

# generar variable
df7['DIAS_DESDE_VACACIONES'] = days_list



# FECHA_CONTRATACION
fechas = list(df7['FECHA_CONTRATACION'])

fechas_new = [f.date() for f in fechas]
deltas = [now.date()-fn for fn in fechas_new]
days_list = [d.days for d in deltas]

df7['DIAS_ANTIGUEDAD'] = days_list

df7 = df7.iloc[:,2:]

del(var7,now,fechas,fechas_new,deltas,days_list)

#%% CONCANETAR DATOS

data = pd.concat([df1,df2,df3,df4,df5,df6,df7],axis=1)
del(df1,df2,df3,df4,df5,df6,df7)

#%% MISSING VALUES

# La unica variable con missing values es EDUCACION
data.isnull().sum().sort_values(ascending=False)

data['EDUCACION'] = data['EDUCACION'].fillna(np.mean(data['EDUCACION']))

data.isnull().sum().sort_values(ascending=False)

#%% ZSCORE

# Para calcular los centroides, mantenemos la data escalada y la no escalada

zscaler = StandardScaler()
zscaler.fit(data)

dfz = zscaler.transform(data)
dfz = pd.DataFrame(dfz, index=data.index, columns=data.columns)

#%% CLUSTERING KMEANS

model = KMeans(10, random_state=14).fit(dfz)
labels = list(model.predict(dfz))
sil = silhouette_score(dfz, labels)

#%% ALGORITMO DE OPTIMIZACION - KMEANS

# TESTEAR MUCHOS K
results = {}

for k in range(2,100):
    print('Numero de Clusters: ',k)
    model = KMeans(k, random_state=14).fit(dfz)
    labels = list(model.predict(dfz))
    sil = silhouette_score(dfz, labels)
    results[k] = [labels, sil]


# CREO UN DATAFRAME PARA VISUALIZAR LOS RESULTADOS
sil_k_list = []

for k in results.keys():
    sil_k_list.append([k,results[k][1]])

sil_k_df = pd.DataFrame(sil_k_list)
sil_k_df.columns = ['Clusters','Score']


# GRAFICO USANDO PLOTLY

fig = px.line(sil_k_df,x='Clusters',y='Score',title='KMEANS OPTIMIZATION',
              markers=True, color_discrete_sequence=['blueviolet'])
offplot(fig)

# LOS K CLUSTERS OPTIMOS SON 5 (0,118 sil) o 7 (0,112 sil)

#%% CENTROIDES

# Añado clusters al dataframe no escalado

dfc = data.copy()
dfc['LABELS'] = results[5][0]

dfc.to_excel('RESULTADOS/BD_SEGMENTADA_5.xlsx')


# Cantidad de persoans por clusters
n = dfc['LABELS'].value_counts()
n = pd.DataFrame(n)
n.columns=['N']
n.sort_index(ascending=True,inplace=True)

# Agrupo los clusters como la media de las variables

centers = dfc.groupby('LABELS').mean()
centers = pd.concat([n,centers],axis=1)
centers = centers.T

centers.to_excel('RESULTADOS/CENTROIDES_5.xlsx')


#%% FORZAR SEGUNDO MEJOR CLUSTERING

dfc = data.copy()
dfc['LABELS'] = results[7][0]

dfc.to_excel('RESULTADOS/BD_SEGMENTADA_7.xlsx')


# Cantidad de persoans por clusters
n = dfc['LABELS'].value_counts()
n = pd.DataFrame(n)
n.columns=['N']
n.sort_index(ascending=True,inplace=True)

# Agrupo los clusters como la media de las variables

centers = dfc.groupby('LABELS').mean()
centers = pd.concat([n,centers],axis=1)
centers = centers.T

centers.to_excel('RESULTADOS/CENTROIDES_7.xlsx')



#%% FILTRAR INFORMACION DE CLUSTERIZACION

features = ['EDAD','N_HIJOS','EXP_RUBRO','SALARIO','NACIONALIDAD','ESTADO_MARITAL','EDUCACION','DIAS_ANTIGUEDAD','DIAS_DESDE_VACACIONES']
dfzf = dfz.loc[:,features] 

# TESTEAR MUCHOS K
results = {}

for k in range(2,100):
    print('Numero de Clusters: ',k)
    model = KMeans(k, random_state=14).fit(dfzf)
    labels = list(model.predict(dfzf))
    sil = silhouette_score(dfzf, labels)
    results[k] = [labels, sil]


# CREO UN DATAFRAME PARA VISUALIZAR LOS RESULTADOS
sil_k_list = []

for k in results.keys():
    sil_k_list.append([k,results[k][1]])

sil_k_df = pd.DataFrame(sil_k_list)
sil_k_df.columns = ['Clusters','Score']


# GRAFICO USANDO PLOTLY

fig = px.line(sil_k_df,x='Clusters',y='Score',title='KMEANS OPTIMIZATION',
              markers=True, color_discrete_sequence=['blueviolet'])
offplot(fig)

# LOS K CLUSTERS OPTIMOS SON 2 (0,157 sil) o 3 (0,146).


#%% CENTROIDES

# Añado clusters al dataframe no escalado

dfc = data.copy()
dfc['LABELS'] = results[2][0]

dfc.to_excel('RESULTADOS/BD_SEGMENTADA_F_2.xlsx')

# Cantidad de persoans por clusters
n = dfc['LABELS'].value_counts()
n = pd.DataFrame(n)
n.columns=['N']
n.sort_index(ascending=True,inplace=True)

# Agrupo los clusters como la media de las variables

centers = dfc.groupby('LABELS').mean()
centers = pd.concat([n,centers],axis=1)
centers = centers.T

centers.to_excel('RESULTADOS/CENTROIDES_F_2.xlsx')


#%% FORZAR SEGUNDO MEJOR CLUSTERING

dfc = data.copy()
dfc['LABELS'] = results[3][0]

dfc.to_excel('RESULTADOS/BD_SEGMENTADA_F_3.xlsx')


# Cantidad de persoans por clusters
n = dfc['LABELS'].value_counts()
n = pd.DataFrame(n)
n.columns=['N']
n.sort_index(ascending=True,inplace=True)

# Agrupo los clusters como la media de las variables

centers = dfc.groupby('LABELS').mean()
centers = pd.concat([n,centers],axis=1)
centers = centers.T

centers.to_excel('RESULTADOS/CENTROIDES_F_3.xlsx')