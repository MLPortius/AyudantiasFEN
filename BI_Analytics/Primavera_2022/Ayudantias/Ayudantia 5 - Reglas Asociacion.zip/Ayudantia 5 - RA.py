# -*- coding: utf-8 -*-
"""
Created on Thu Nov 10 20:52:16 2022

@author: Andriu
"""

# !pip install mlxtend --upgrade

#%% IMPORTAR LIBRERIAS

import warnings 
warnings.filterwarnings('ignore')

import pandas as pd

from mlxtend.frequent_patterns import apriori
from mlxtend.frequent_patterns import fpgrowth
from mlxtend.frequent_patterns import association_rules

import time
 
import plotly.express as px
from plotly.offline import plot as offplot

#%% CARGAR DATOS PREPARADOS

df = pd.read_excel('BD_REGLAS_PREPARADO.xlsx')
df.set_index('ID',drop=True,inplace=True)

#%% REGLAS DE ASOCIACION

ap_frequent = apriori(df,min_support=0.1,use_colnames=True,verbose=True)
rules = association_rules(ap_frequent,metric='lift',min_threshold=2)

fp_frequent = fpgrowth(df,min_support=0.1,verbose=1,use_colnames=True)
rules_2 = association_rules(fp_frequent,metric='lift',min_threshold=2)

#%% MEDICION DE CALCULO

grid = [x/1000 for x in list(range(3,100))]
grid = grid[::-1]

runs_ap = []
for g in grid:
    print('apriori:',g)
    start = time.time()
    ap_frecuent = apriori(df,min_support=g,use_colnames=True)
    end = time.time()
    seconds = end - start
    runs_ap.append([g,seconds]) 
    
runs_fp = []
for g in grid:
    print('fpgrowth:',g)
    start = time.time()
    fp_frecuent = fpgrowth(df,min_support=g,use_colnames=True)
    end = time.time()
    seconds = end - start
    runs_fp.append([g,seconds]) 
    

ap = pd.DataFrame(runs_ap,columns=['support','time_ap'])
fp = pd.DataFrame(runs_fp,columns=['support','time_fp'])

comp = pd.concat([ap,fp],axis=1)
comp['loop'] = comp.index

fig = px.line(comp,x='loop',y=['time_ap','time_fp'])
offplot(fig)


#%% LIMPIAR FORMATO

def frozenset_list(x):
    y = list(x)
    return y

rules['antecedents'] = rules['antecedents'].apply(frozenset_list)
rules['consequents'] = rules['consequents'].apply(frozenset_list)

rules.to_excel('OUTPUT/RULES.xlsx')

#%% FILTRAR REGLAS ENCONTRADAS

filter_ant = 'África'
def search_ant(x):
    b = filter_ant in x
    if b:
        return 1
    else:
        return 0
    
rules[filter_ant] = rules['antecedents'].apply(search_ant)
rules_filtered = rules[rules[filter_ant]==1]

def count_ant(x):
    y = len(x)
    return y

rules_filtered['count'] = rules_filtered['antecedents'].apply(count_ant)
rules_filtered_2 = rules_filtered[rules_filtered['count']==2]

def recommend(rules,f_ant,f_n=False):
    filter_ant = f_ant
    filter_count = f_n
    
    rules[filter_ant] = rules['antecedents'].apply(search_ant)
    rules_filtered = rules.loc[rules[filter_ant]==1]
    
    if filter_count == False:
        return rules_filtered
    else:
        rules_filtered['count'] = rules_filtered['antecedents'].apply(count_ant)
        rules_filtered_2 = rules_filtered.loc[rules_filtered['count']==filter_count]
        return rules_filtered_2

def get_recommendations(rules,filter_ant):
    a = rules['consequents']
    l1 = []
    for l in a:
        l1 = l1 + l
    s = pd.Series(l1)
    vc = s.value_counts()
    vc = vc/len(a)
    vc = vc.to_frame()
    vc.columns = [filter_ant]
    return vc


#%% RECOMMENDATION SYSTEM

def search_ant(x):
    b = filter_ant in x
    if b:
        return 1
    else:
        return 0
    
def count_ant(x):
    y = len(x)
    return y

def recommend(rules,f_ant,f_n=False):
    filter_ant = f_ant
    filter_count = f_n
    
    rules[filter_ant] = rules['antecedents'].apply(search_ant)
    rules_filtered = rules.loc[rules[filter_ant]==1]
    
    if filter_count == False:
        return rules_filtered
    else:
        rules_filtered['count'] = rules_filtered['antecedents'].apply(count_ant)
        rules_filtered_2 = rules_filtered.loc[rules_filtered['count']==filter_count]
        return rules_filtered_2

def get_recommendations(rules,filter_ant):
    a = rules['consequents']
    l1 = []
    for l in a:
        l1 = l1 + l
    s = pd.Series(l1)
    vc = s.value_counts()
    vc = vc/len(a)
    vc = vc.to_frame()
    vc.columns = [filter_ant]
    return vc



#%% CALCULATING RECOMMENDATION RULES

print('Calculating Frequents...')
fp_frequent = fpgrowth(df,min_support=0.01,verbose=0,use_colnames=True)

print('Searching for Rules...')
rules = association_rules(fp_frequent,metric='lift',min_threshold=4)

print('Cleaning Rules Table...')
rules['antecedents'] = rules['antecedents'].apply(frozenset_list)
rules['consequents'] = rules['consequents'].apply(frozenset_list)

#%% 
print('Filtering Antecedent...')
filter_ant = 'América del Sur'

print('Searching Recommendations...')
rules_f = recommend(rules,filter_ant,f_n=1)
reco = get_recommendations(rules_f,filter_ant)

print('Tus recomendaciones son:')
print(reco)
