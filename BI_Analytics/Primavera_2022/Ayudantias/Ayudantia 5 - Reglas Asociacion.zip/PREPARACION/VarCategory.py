# -*- coding: utf-8 -*-
"""
Created on Thu Nov 10 15:17:44 2022

@author: Andriu
"""


#%% INSTALAR LIBRERIAS

# !pip install mlxtend --upgrade


#%% IMPORTAR LIBRERIAS

import pandas as pd
import numpy as np

#%% CARGAR DATOS

PAIS = pd.read_excel('Selected4.xlsx',sheet_name='PAISES')
NIVEL = pd.read_excel('Selected4.xlsx',sheet_name='NIVEL')
TENDENCIAS = pd.read_excel('Selected4.xlsx',sheet_name='TENDENCIA')

PAIS.set_index('ID',drop=True,inplace=True)
NIVEL.set_index('ID',drop=True,inplace=True)
TENDENCIAS.set_index('ID',drop=True,inplace=True)

#%%

def POSNEG(serie):
    p = serie[serie>0]
    n = serie[serie<0]
    c = serie[serie==0]
    ps = (p/max(p))*100
    ns = (n/abs(min(n)))*100
    
    out = pd.concat([ps,c,ns],axis=0)

    vin = list(serie.index)    
    vout = list(out.index)
    
    outliers = []
    for ind in vin:
        if not (ind in vout):
            outliers.append(ind)
    
    ol = serie.loc[outliers]
    output = pd.concat([out,ol],axis=0)
    output = output.loc[vin]
    
    return output


def QUANTIZE(serie):
    v = serie
    vs = POSNEG(v)
    
    vp = vs[vs>0]
    vp.sort_values(ascending=True,inplace=True)
    
    vn = vs[vs<0]
    vn.sort_values(ascending=False,inplace=True)
    
    c = vs[vs==0]
    
    vp_li = int(np.round(len(vp)*0.1,0))
    vp_ls = int(np.round(len(vp)*0.7,0))
    
    vn_li = int(np.round(len(vn)*0.1,0))
    vn_ls = int(np.round(len(vn)*0.7,0))

    vp_inf = vp.iloc[:vp_li]
    vp_mid = vp.iloc[vp_li:vp_ls]
    vp_sup = vp.iloc[vp_ls:]
    
    vn_inf = vn.iloc[:vn_li]
    vn_mid = vn.iloc[vn_li:vn_ls]
    vn_sup = vn.iloc[vn_ls:]
    
    output = vs.copy()
    output.loc[vp_sup.index] = 'PA'
    output.loc[vp_mid.index] = 'PB'
    output.loc[vp_inf.index] = 'N'
    output.loc[vn_inf.index] = 'N'
    output.loc[vn_mid.index] = 'NB'
    output.loc[vn_sup.index] = 'NA'
    output.loc[c.index] = 'N'

    return output
    
def MINMAX(serie):
    s = serie
    smi = s-s.min()
    sma = smi/smi.max()
    return sma

def CAT_THREE(x,qs,qi):
    if x > qs:
        return 'ALTO'
    elif (x <= qs and x > qi):
        return 'MEDIO'
    elif (x <= qi):
        return 'BAJO'
    else:
        return x
    
def QUANTILE_QUANTIZE(serie):
    s = serie
    ss = MINMAX(s)
    
    qs = ss.quantile(0.6)
    qi = ss.quantile(0.3)
    
    ssl = list(ss)
    sss = [CAT_THREE(i, qs, qi) for i in ssl]
    sss = pd.Series(sss,index=ss.index)
    
    return sss

#%% CATEGORICAS

TENDENCIASC = TENDENCIAS.copy()
for var in list(TENDENCIAS.columns):    
    TENDENCIASC[var] = QUANTIZE(TENDENCIASC[var])
del(var)

TENDENCIASC.sort_index(axis=0,ascending=True,inplace=True)

NIVELC = NIVEL.copy()
for var in list(NIVEL.columns):
    NIVELC[var] = QUANTILE_QUANTIZE(NIVELC[var])
del(var)

NIVELC.sort_index(axis=0,ascending=True,inplace=True)

#%% CATEGORIA BINARIA

REGION = PAIS['REGION']
REGION = pd.get_dummies(REGION,dtype=int)

for var in list(REGION.columns):    
    REGION[var] = REGION[var].map({1:var,0:np.nan})

#%% CONCATENAR

REGION.to_excel('REGION.xlsx')
TENDENCIASC.to_excel('TEND.xlsx')
NIVELC.to_excel('NIV.xlsx')
