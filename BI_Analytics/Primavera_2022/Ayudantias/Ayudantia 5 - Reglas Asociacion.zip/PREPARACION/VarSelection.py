# -*- coding: utf-8 -*-
"""
Created on Mon Nov  7 16:14:50 2022

@author: Andriu
"""

#%% IMPORTAR LIBRERIAS

import pandas as pd
import numpy as np
import plotly.express as px
from plotly.offline import plot

#%% CARGAR DATOS

df = pd.read_excel('BD_Ratios_Mundo.xlsx')
df.set_index('ID',drop=True,inplace=True)

#%% SELECCION DE ATRIBUTOS

# CLASIFICAR VARIABLES
variables = {}
for var in list(df.columns):
    name = var.split('_')[0]
    clas = var.split('_')[1]
    rango = var.split('_')[2]
    dicto = {'name':name,'class':clas,'range':rango}

    variables[var] = pd.DataFrame(dicto.values(),index=dicto.keys(),columns=[var])
    
for key in variables.keys():
    if list(variables.keys())[0] == key:
        vartab = variables[key]
    else:
        vartab = pd.concat([vartab,variables[key]],axis=1)

vartab = vartab.T

# SELECCIONAR CONFIANZA EN LAS VARIABLES
confvars = list(vartab[vartab['class']=='conf'].index)
confdf = df.loc[:,confvars]
confdfm = confdf.mean(axis=0).to_frame()
confdfm.columns = ['confmean']

confdfm['name'] = [x.split('_')[0] for x in list(confdfm.index)]

# OBTENER CONFIANZA PROMEDIO POR TIPO DE VARIABLE
confmeans = confdfm.groupby('name').mean()
confmeans.sort_values('confmean',ascending=False,inplace=True)
confiable = list(confmeans[confmeans['confmean'] >= 0.9].index)

cv = []
for n in confiable:
    cv =  cv + list(vartab.loc[vartab['name'] == n].index)

dfselected = df.loc[:,cv]
dfselected.to_excel('Selected.xlsx')

vt1 = vartab.loc[vartab['class']!='conf',:]
vt2 = vt1.loc[vt1['range'] == 'cp',:]

selected2 = list(vt2.index)
dfselected2 = df.loc[:,selected2]
dfselected2.to_excel('Selected2.xlsx')

#%%

fig = px.scatter(dfselected2,x='PPC_mean_cp',y='PPC_alpha_cp')
plot(fig)

#%% 

vt3 = pd.concat([vt2[vt2['class']=='alpha'],vt2[vt2['class']=='beta']],axis=0)
selected3 = list(vt3.index)

dfselected3 = df.loc[:,selected3]

dfselected3.columns = [x.split('_')[0]+'_'+x.split('_')[1] for x in selected3]
dfselected3.to_excel('Selected3.xlsx')

selected32 = [x.split('_')[0]+'_'+x.split('_')[1] for x in selected3]

selected33 = []
for var in selected32:
    n = var.split('_')[0]
    c = var.split('_')[1]
    if c == 'alpha':
        c2 = 'NIVEL'
    elif c== 'beta':
        c2 = 'TENDENCIA'
    var2 = n + '_' + c2
    selected33.append(var2)
    
dfselected4 = dfselected3.copy()
dfselected4.columns = selected33
dfselected4.to_excel('Selected4.xlsx')
