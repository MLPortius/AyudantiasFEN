# -*- coding: utf-8 -*-
"""
Created on Thu Nov 10 18:46:41 2022

@author: Andriu
"""

#%% IMPORTAR LIBRERIAS

import numpy as np
import pandas as pd

#%% CARGAR DATOS

df1 = pd.read_excel('BD_Reglas_Mundo.xlsx',sheet_name='MONEDA')
df2 = pd.read_excel('BD_Reglas_Mundo.xlsx',sheet_name='REGION')
df3 = pd.read_excel('BD_Reglas_Mundo.xlsx',sheet_name='TENDENCIA')

df1.set_index('ID',drop=True,inplace=True)
df2.set_index('ID',drop=True,inplace=True)
df3.set_index('ID',drop=True,inplace=True)

#%% FILTRO

indice = list(df3.index)

df1 = df1.loc[indice,:]
df2 = df2.loc[indice,:]

del(indice)

#%% CATEGORICO

# Junto todas las variables TIPO 1
# df3

# Logro hacer el preproceso para una
# vname = 'PPC_TENDENCIA'
# s = df3[vname]
# d = pd.get_dummies(s,prefix=vname,dtype=int)

# Repito para todas y guardo los resultados
dum = []
for var in list(df3.columns):
    s = df3[var]
    d = pd.get_dummies(s,prefix=var,dtype=int)
    dum.append(d)
    
# Saco todos los resultados a un unico DF
df_t1 = dum[0]
for d in dum[1:]:
    df_t1 = pd.concat([df_t1,d],axis=1)

del(s,d,dum,var)

#%% BINARIA NOMINAL

# vname = 'REGION1'
# s = df2[vname]
# d = pd.get_dummies(s,dtype=int)

dum = []
for var in list(df2.columns):
    s = df2[var]
    d = pd.get_dummies(s,dtype=int)
    dum.append(d)

df_t2 = dum[0]
for d in dum[1:]:
    df_t2 = pd.concat([df_t2,d],axis=1)

del(s,d,dum,var)

#%% CONTINUA A CATEGORICA

s = df1['TIPO_USD'].copy()
s.sort_values(ascending=True,inplace=True)


# DIVISION BINARIA PORCENTAJE - PORCENTAJE
p = 0.5
size = int(np.round(len(s)*p,0))

sb = s.iloc[:size]
sa = s.iloc[size:]

def BAJO_CAT(x):
    return 'BAJO'
def ALTO_CAT(x):
    return 'ALTO'

sbc = sb.apply(BAJO_CAT)
sac = sa.apply(ALTO_CAT)

sc1 = pd.concat([sbc,sac],axis=0)
sc1.sort_index(inplace=True)

del(p,size,sb,sa,sbc,sac)

sc1.value_counts()/len(sc1)

# DIVISION BINARIA POR MEDIA
mn = s.mean()

def MEAN_CAT(x):
    if x >= mn:
        return 'ALTO'
    else:
        return 'BAJO'
    
sc2 = s.apply(MEAN_CAT)
sc2.sort_index(inplace=True)

sc2.value_counts()/len(sc1)


# DIVISION POR PERCENTIL
qi = 0.20
qs = 0.80

pi = s.quantile(qi)
ps = s.quantile(qs)

def PER_CAT(x):
    if x > ps:
        return 'ALTO'
    elif x < pi:
        return 'BAJO'
    else:
        return 'MEDIO'

sc3 = s.apply(PER_CAT)
sc3.sort_index(inplace=True)

sc3.value_counts()/len(sc3)

# DIVISION AUTOMATICA QCUT
g = 3

sc4 = pd.qcut(s,g,['BAJO','MEDIO','ALTO'])
sc4.sort_index(inplace=True)

sc4.value_counts()/len(sc4)

# DIVISION AUTOMATICA CUT
g = 3

sc5 = pd.cut(s,bins=g,labels=['BAJO','MEDIO','ALTO'])
sc5.sort_index(inplace=True)

sc5.value_counts()/len(sc5)

# DIVISION POR CRITERIO

valor_corte_sup = 0.8256
valor_corte_inf = 0.0955

def CRIT_CAT(x):
    if x > valor_corte_sup:
        return 'ALTO'
    elif x < valor_corte_inf:
        return 'BAJO'
    else:
        return 'MEDIO'

sc6 = s.apply(CRIT_CAT)
sc6.sort_index(inplace=True)

sc6.value_counts()/len(sc6)

# PARA ESTE CASO USAREMOS EL PERCENTIL
dfc = s.to_frame()
dfc.sort_index(inplace=True)

dfc['CATEGORIA'] = sc3

#%% CATEGORIA A DUMMIES

df_t3 = pd.get_dummies(dfc['CATEGORIA'],prefix='MONEDA',dtype=int)


#%% CONCATENAR TODOS LOS RESULTADOS

df = pd.concat([df_t1,df_t2,df_t3],axis=1)

dfb = df.astype(bool)

dfb.to_excel('BD_REGLAS_PREPARADO.xlsx')

